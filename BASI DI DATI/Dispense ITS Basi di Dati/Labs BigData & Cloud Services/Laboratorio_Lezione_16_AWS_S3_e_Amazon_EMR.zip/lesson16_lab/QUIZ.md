# Quiz finale — AWS, S3 ed Amazon EMR

1. Quale risorsa AWS definisce il confine amministrativo e di fatturazione principale? A) AZ B) Account C) Bucket D) Executor
2. Perché un runtime role è preferibile a chiavi permanenti nel codice? A) È più veloce B) Offre credenziali temporanee e permessi controllati C) Crea S3 D) Evita Spark
3. Che cosa contiene un bucket S3? A) Blocchi HDFS B) Oggetti identificati da key C) Tabelle RAM D) Executor
4. Che cosa accade ai dati HDFS quando un cluster EMR su EC2 viene terminato? A) Restano in S3 B) Sono effimeri e vengono persi C) Passano a Glue D) Diventano pubblici
5. Quale modalità EMR usiamo nel laboratorio? A) EC2 cluster B) EKS C) Serverless D) Local
6. EMR Serverless supporta HDFS? A) Sì B) No, usa dischi temporanei per shuffle e processing C) Solo in Italia D) Solo con Spark SQL
7. A che cosa serve `iam:PassRole`? A) Leggere oggetti B) Consentire al chiamante di passare un ruolo approvato al servizio C) Cifrare S3 D) Creare una Region
8. Dove salviamo input, output e log del laboratorio? A) Nel driver B) In S3 C) In HDFS Serverless D) Nel browser
9. Che cosa mostra `billedResourceUtilization`? A) Saldo bancario B) Risorse aggregate fatturate al job C) Numero di bucket pubblici D) Password IAM
10. Qual è l’ultimo passaggio obbligatorio? A) Aumentare executor B) Rendere pubblico il bucket C) Verificare e pulire le risorse D) Disattivare i log

## Soluzioni

1B, 2B, 3B, 4B, 5C, 6B, 7B, 8B, 9B, 10C.

