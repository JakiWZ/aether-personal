#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_FILE="${LAB_ROOT}/config/lab.env"
STATE_FILE="${LAB_ROOT}/.dataflix-l16-state.env"

load_config() {
  if [[ ! -f "${CONFIG_FILE}" ]]; then
    echo "Manca config/lab.env. Copia config/lab.env.example e completalo." >&2
    exit 2
  fi
  set -a
  # Il file è creato e controllato dallo studente nella cartella del laboratorio.
  source "${CONFIG_FILE}"
  set +a
  : "${AWS_REGION:?AWS_REGION mancante}"
  : "${AWS_PROFILE:?AWS_PROFILE mancante}"
  : "${EMR_RELEASE_LABEL:?EMR_RELEASE_LABEL mancante}"
  : "${DATASET_ROWS:?DATASET_ROWS mancante}"
  export AWS_DEFAULT_REGION="${AWS_REGION}"
  export AWS_PROFILE
}

load_state() {
  if [[ ! -f "${STATE_FILE}" ]]; then
    echo "Manca lo stato ${STATE_FILE}. Esegui gli script nell'ordine indicato." >&2
    exit 2
  fi
  set -a
  source "${STATE_FILE}"
  set +a
}

save_state_value() {
  local key="$1" value="$2"
  if [[ ! "${key}" =~ ^[A-Z0-9_]+$ ]]; then
    echo "Chiave di stato non valida: ${key}" >&2
    exit 2
  fi
  touch "${STATE_FILE}"
  if grep -q "^${key}=" "${STATE_FILE}"; then
    python3 - "${STATE_FILE}" "${key}" "${value}" <<'PY'
from pathlib import Path
import sys
path, key, value = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
lines = path.read_text(encoding='utf-8').splitlines()
path.write_text('\n'.join(f'{key}={value}' if line.startswith(key+'=') else line for line in lines)+'\n', encoding='utf-8')
PY
  else
    printf '%s=%s\n' "${key}" "${value}" >> "${STATE_FILE}"
  fi
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || { echo "Comando richiesto non trovato: $1" >&2; exit 2; }
}

require_lab_bucket() {
  : "${BUCKET_NAME:?BUCKET_NAME mancante nello stato}"
  if [[ ! "${BUCKET_NAME}" =~ ^dataflix-l16-[0-9]{12}-[0-9]{8,14}$ ]]; then
    echo "Target rifiutato: il bucket non rispetta il prefisso sicuro del laboratorio." >&2
    exit 3
  fi
}

