# Laboratorio 16 — DATAFLIX entra nel cloud

Durata: **150 minuti**. Architettura: **Amazon S3 + Amazon EMR Serverless + PySpark**. Il laboratorio usa risorse AWS reali e può generare costi: eseguilo soltanto in un account didattico autorizzato, nella regione approvata e con il docente presente.

## Perché EMR Serverless

La teoria copre anche EMR su EC2, con nodi primary/core/task, YARN e HDFS. Il laboratorio usa Serverless per ridurre l’amministrazione e imporre limiti di capacità. **EMR Serverless non supporta HDFS**: input, output e log persistenti risiedono in S3; i dischi dei worker sono temporanei.

## Prerequisiti amministrativi

- account AWS Academy, sandbox o account aziendale espressamente autorizzato;
- AWS CLI v2 configurata con credenziali temporanee o SSO;
- permessi per S3 ed EMR Serverless;
- permesso `iam:PassRole` sul runtime role approvato;
- facoltativamente permessi IAM per creare il runtime role;
- nessuna chiave AWS salvata nei file del laboratorio.

Il docente deve verificare prima della lezione quote, disponibilità regionale, release label e policy dell’ambiente. Il valore predefinito è `eu-west-1` e la release bloccata è `emr-7.13.0`.

## Configurazione

```bash
cp config/lab.env.example config/lab.env
```

Modifica `config/lab.env`. Se il corso fornisce un ruolo, inserisci il suo ARN in `RUNTIME_ROLE_ARN`. Non usare il ruolo root e non inserire access key nel file.

Rendi eseguibili gli script su Linux/macOS/WSL:

```bash
chmod +x scripts/*.sh
```

## Percorso operativo

### 1. Preflight

```bash
./scripts/00_preflight.sh
```

Conserva l’ARN restituito in `evidence/observations.md`.

### 2. Storage protetto

```bash
./scripts/01_create_storage.sh
```

Lo script crea un bucket dal prefisso controllato, abilita tutti i blocchi di accesso pubblico, configura SSE-S3, tag e scadenza degli oggetti dopo sette giorni.

### 3. Runtime role

Se il ruolo è già fornito:

```bash
./scripts/02_create_runtime_role.sh
```

Lo script registra l’ARN. Se è vuoto e possiedi i permessi IAM, crea un ruolo che può leggere e scrivere **soltanto nel bucket del laboratorio**. In AWS Academy questa operazione può essere vietata: usa il ruolo indicato dal docente.

### 4. Dataset e codice

```bash
./scripts/03_generate_and_upload.sh
```

Vengono generati 200.000 eventi validi e 20 righe errate. Imposta al massimo `DATASET_ROWS=1000000`; valori superiori sono rifiutati dal generatore.

### 5. Applicazione con guardrail

```bash
./scripts/04_create_application.sh
```

La capacità massima è 8 vCPU, 32 GB di memoria e 40 GB di disco; auto-start è attivo e auto-stop scatta dopo cinque minuti inattivi.

### 6. Job PySpark

```bash
./scripts/05_submit_job.sh
./scripts/06_wait_and_collect.sh
```

Il job ha timeout di 30 minuti. Durante l’esecuzione apri la console EMR Serverless e osserva stato, Spark UI e log. Gli output finiscono sotto `runs/<timestamp>/output/`.

### 7. Evidence gate

```bash
python3 scripts/07_verify_cloud.py
```

Il gate verifica:

- stato `SUCCESS`;
- `_SUCCESS` per curated, top, country e metrics;
- 200.020 righe raw, 200.000 valide e 20 non valide;
- `MOV-0042` con 16.000 eventi;
- disponibilità di `billedResourceUtilization` nel report del job.

Completa anche `evidence/observations.md`.

### 8. Pulizia obbligatoria

Prima conserva `evidence/runtime`. Poi:

```bash
./scripts/99_cleanup.sh
```

Lo script mostra i target, richiede la parola `CLEANUP`, rifiuta bucket o ruoli senza il prefisso del laboratorio, annulla l’eventuale job ancora attivo, elimina l’applicazione, svuota ed elimina il bucket e rimuove soltanto l’eventuale ruolo creato dal laboratorio. Infine salva `evidence/runtime/cleanup-verification.txt` con l’esito dei controlli.

Verifica infine:

```bash
aws emr-serverless get-application --application-id "<APP_ID>"
aws s3api head-bucket --bucket "<BUCKET_NAME>"
```

Entrambi devono restituire un errore di risorsa non trovata/accesso al bucket inesistente.

## Scaletta dei 150 minuti

| Minuti | Attività | Evidenza |
|---:|---|---|
| 0–15 | Identità, regione, autorizzazioni | ARN e preflight |
| 15–35 | S3 e controlli di sicurezza | Public Access Block, encryption, tag |
| 35–50 | Runtime role e least privilege | policy limitata al bucket |
| 50–70 | Dataset e layout S3 | input/code/expected |
| 70–90 | Applicazione EMR Serverless | Application ID e capacità massima |
| 90–115 | Job PySpark e monitoraggio | Job ID, stato, Spark UI, log |
| 115–130 | Output ed evidence gate | Parquet, metrics, utilizzo fatturato |
| 130–150 | Debrief e pulizia | risorse eliminate |

## Se non sono disponibili i permessi AWS

Il docente esegue gli script 01, 02 e 04 una sola volta e distribuisce bucket, Application ID e runtime role per l’osservazione guidata. Gli studenti lavorano in gruppi sul job, sul report e sul piano architetturale. Non tentare di aggirare policy o permessi dell’account didattico.
