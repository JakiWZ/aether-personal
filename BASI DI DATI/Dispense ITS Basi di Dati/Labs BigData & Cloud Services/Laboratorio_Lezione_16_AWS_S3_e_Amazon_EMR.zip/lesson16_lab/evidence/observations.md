# Osservazioni — Lezione 16

## Identità e sicurezza

- ARN dell’identità chiamante:
- Regione:
- ARN del runtime role:
- Perché il runtime role non riceve accesso a tutti i bucket:
- Prova che Block Public Access è attivo:

## Esecuzione

- Application ID:
- Job run ID:
- Stato finale e durata:
- State details:
- vCPU-hour, GB-hour e storage riportati da `billedResourceUtilization`:

## Dati

- URI di input:
- URI di output:
- Conteggi raw / valid / invalid:
- Film più frequente:
- Differenza osservata fra HDFS e S3 in questa architettura:

## Tre decisioni architetturali

1. Decisione, vantaggio, rischio:
2. Decisione, vantaggio, rischio:
3. Decisione, vantaggio, rischio:

## Pulizia

- Application eliminata:
- Bucket eliminato:
- Ruolo eliminato oppure dichiarato esterno:
- Comando di verifica finale:

