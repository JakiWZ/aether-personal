#!/usr/bin/env python3
"""Job PySpark DATAFLIX per Amazon EMR Serverless."""

from __future__ import annotations
import argparse
from pyspark.sql import SparkSession, functions as F, types as T

RAW_SCHEMA=T.StructType([
    T.StructField('event_id_raw',T.StringType()),T.StructField('user_id_raw',T.StringType()),
    T.StructField('movie_id_raw',T.StringType()),T.StructField('event_ts_raw',T.StringType()),
    T.StructField('duration_seconds_raw',T.StringType()),T.StructField('country_raw',T.StringType()),
    T.StructField('device_raw',T.StringType()),T.StructField('quality_raw',T.StringType()),
    T.StructField('event_type_raw',T.StringType()),T.StructField('subscription_plan_raw',T.StringType()),
])


def args():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); return p.parse_args()


def main():
    a=args(); spark=SparkSession.builder.appName('DATAFLIX-L16-EMR').getOrCreate(); spark.sparkContext.setLogLevel('WARN')
    raw=spark.read.option('header',True).option('mode','PERMISSIVE').schema(RAW_SCHEMA).csv(a.input)
    parsed=raw.select(
        F.trim('event_id_raw').alias('event_id'),F.trim('user_id_raw').alias('user_id'),F.trim('movie_id_raw').alias('movie_id'),
        F.expr("try_to_timestamp(event_ts_raw, 'yyyy-MM-dd HH:mm:ss')").alias('event_ts'),
        F.expr('try_cast(duration_seconds_raw AS INT)').alias('duration_seconds'),
        F.upper(F.trim('country_raw')).alias('country'),F.lower(F.trim('device_raw')).alias('device'),
        F.upper(F.trim('quality_raw')).alias('quality'),F.lower(F.trim('event_type_raw')).alias('event_type'),
        F.lower(F.trim('subscription_plan_raw')).alias('subscription_plan'))
    valid=(F.col('event_id').isNotNull() & F.col('user_id').isNotNull() & F.col('movie_id').isNotNull() &
           F.col('event_ts').isNotNull() & F.col('duration_seconds').between(0,28800) & F.col('country').isNotNull() &
           (F.length('country')>0) & F.col('event_type').isin('play','pause','complete','error') &
           F.col('device').isin('mobile','tv','web','tablet') & F.col('quality').isin('SD','HD','FHD','4K') &
           F.col('subscription_plan').isin('basic','standard','premium'))
    curated=parsed.filter(valid).withColumn('event_date',F.to_date('event_ts')).cache()
    raw_count=raw.count(); valid_count=curated.count(); invalid_count=raw_count-valid_count
    top=(curated.groupBy('movie_id').agg(F.count('*').alias('events'),F.sum('duration_seconds').alias('seconds'))
         .orderBy(F.desc('events'),F.asc('movie_id')))
    countries=(curated.groupBy('country').agg(F.round(F.sum('duration_seconds')/60.0,2).alias('minutes'),F.countDistinct('user_id').alias('users'))
               .orderBy(F.desc('minutes')))
    top_row=top.first()
    (curated.repartition(8,'event_date').write.mode('overwrite').partitionBy('event_date').parquet(f'{a.output}/curated_events'))
    top.write.mode('overwrite').parquet(f'{a.output}/top_movies')
    countries.write.mode('overwrite').parquet(f'{a.output}/country_minutes')
    metric_schema='raw_count long, valid_count long, invalid_count long, top_movie_id string, top_movie_count long'
    spark.createDataFrame([(raw_count,valid_count,invalid_count,top_row['movie_id'],top_row['events'])],metric_schema).coalesce(1).write.mode('overwrite').json(f'{a.output}/metrics')
    curated.unpersist(); spark.stop()


if __name__=='__main__': main()

