#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
load_state
require_command aws
require_lab_bucket
: "${APP_ID:?APP_ID mancante}"

ROLE_ARN="${RUNTIME_ROLE_ARN:-}"
if [[ -z "${ROLE_ARN}" ]]; then
  echo "RUNTIME_ROLE_ARN mancante. Esegui 02_create_runtime_role.sh o impostalo nel config." >&2
  exit 2
fi

RUN_PREFIX="runs/$(date -u +%Y%m%d%H%M%S)"
REQUEST_DIR="${LAB_ROOT}/build/job-${LAB_SUFFIX}"
python3 "${LAB_ROOT}/scripts/build_job_request.py" --bucket "${BUCKET_NAME}" --run-prefix "${RUN_PREFIX}" --output-dir "${REQUEST_DIR}"

JOB_RUN_ID="$(aws emr-serverless start-job-run \
  --application-id "${APP_ID}" \
  --execution-role-arn "${ROLE_ARN}" \
  --name "dataflix-l16-${LAB_SUFFIX}" \
  --execution-timeout-minutes 30 \
  --job-driver "file://${REQUEST_DIR}/job-driver.json" \
  --configuration-overrides "file://${REQUEST_DIR}/configuration-overrides.json" \
  --tags Project=DATAFLIX,Lesson=16,ManagedBy=lab-script \
  --query jobRunId --output text)"

save_state_value RUNTIME_ROLE_ARN "${ROLE_ARN}"
save_state_value RUN_PREFIX "${RUN_PREFIX}"
save_state_value JOB_RUN_ID "${JOB_RUN_ID}"
echo "Job inviato: ${JOB_RUN_ID}"
