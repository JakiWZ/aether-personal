#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
load_state
require_command aws
require_lab_bucket

echo "Target verificati: application=${APP_ID:-nessuna}, bucket=${BUCKET_NAME}, role=${RUNTIME_ROLE_NAME:-esterno}"
read -r -p "Scrivi CLEANUP per eliminare soltanto queste risorse: " CONFIRM
[[ "${CONFIRM}" == "CLEANUP" ]] || { echo "Pulizia annullata."; exit 2; }

if [[ -n "${APP_ID:-}" && -n "${JOB_RUN_ID:-}" ]]; then
  JOB_STATE="$(aws emr-serverless get-job-run --application-id "${APP_ID}" --job-run-id "${JOB_RUN_ID}" --query jobRun.state --output text 2>/dev/null || true)"
  case "${JOB_STATE}" in
    SUBMITTED|PENDING|SCHEDULED|QUEUED|RUNNING)
      aws emr-serverless cancel-job-run --application-id "${APP_ID}" --job-run-id "${JOB_RUN_ID}" >/dev/null
      for _ in $(seq 1 60); do
        JOB_STATE="$(aws emr-serverless get-job-run --application-id "${APP_ID}" --job-run-id "${JOB_RUN_ID}" --query jobRun.state --output text 2>/dev/null || true)"
        [[ "${JOB_STATE}" == "CANCELLED" || "${JOB_STATE}" == "FAILED" || "${JOB_STATE}" == "SUCCESS" || -z "${JOB_STATE}" ]] && break
        sleep 5
      done
      ;;
  esac
fi

if [[ -n "${APP_ID:-}" ]]; then
  STATE="$(aws emr-serverless get-application --application-id "${APP_ID}" --query application.state --output text 2>/dev/null || true)"
  if [[ "${STATE}" == "STARTED" || "${STATE}" == "STARTING" ]]; then
    aws emr-serverless stop-application --application-id "${APP_ID}"
    for _ in $(seq 1 60); do
      STATE="$(aws emr-serverless get-application --application-id "${APP_ID}" --query application.state --output text 2>/dev/null || true)"
      [[ "${STATE}" == "STOPPED" ]] && break
      sleep 5
    done
  fi
  aws emr-serverless delete-application --application-id "${APP_ID}" 2>/dev/null || true
fi

aws s3 rm "s3://${BUCKET_NAME}" --recursive --only-show-errors
aws s3api delete-bucket --bucket "${BUCKET_NAME}" --region "${AWS_REGION}"

if [[ -n "${RUNTIME_ROLE_NAME:-}" ]]; then
  if [[ ! "${RUNTIME_ROLE_NAME}" =~ ^DataflixL16EMRRole-[0-9]{14}$ ]]; then
    echo "Ruolo non eliminato: nome non conforme al prefisso sicuro." >&2
    exit 3
  fi
  aws iam delete-role-policy --role-name "${RUNTIME_ROLE_NAME}" --policy-name "${RUNTIME_POLICY_NAME}"
  aws iam delete-role --role-name "${RUNTIME_ROLE_NAME}"
fi

mkdir -p "${LAB_ROOT}/evidence/runtime"
VERIFY_FILE="${LAB_ROOT}/evidence/runtime/cleanup-verification.txt"
: > "${VERIFY_FILE}"
if [[ -n "${APP_ID:-}" ]] && aws emr-serverless get-application --application-id "${APP_ID}" >/dev/null 2>&1; then
  echo "FAIL application ancora presente: ${APP_ID}" | tee -a "${VERIFY_FILE}"; exit 4
else
  echo "OK application non trovata: ${APP_ID:-nessuna}" | tee -a "${VERIFY_FILE}"
fi
if aws s3api head-bucket --bucket "${BUCKET_NAME}" >/dev/null 2>&1; then
  echo "FAIL bucket ancora presente: ${BUCKET_NAME}" | tee -a "${VERIFY_FILE}"; exit 4
else
  echo "OK bucket non trovato: ${BUCKET_NAME}" | tee -a "${VERIFY_FILE}"
fi
if [[ -n "${RUNTIME_ROLE_NAME:-}" ]]; then
  if aws iam get-role --role-name "${RUNTIME_ROLE_NAME}" >/dev/null 2>&1; then
    echo "FAIL ruolo ancora presente: ${RUNTIME_ROLE_NAME}" | tee -a "${VERIFY_FILE}"; exit 4
  else
    echo "OK ruolo non trovato: ${RUNTIME_ROLE_NAME}" | tee -a "${VERIFY_FILE}"
  fi
else
  echo "SKIP ruolo esterno non gestito dal laboratorio" | tee -a "${VERIFY_FILE}"
fi
echo "Pulizia completata e verificata. Conserva evidence/runtime come prova."
