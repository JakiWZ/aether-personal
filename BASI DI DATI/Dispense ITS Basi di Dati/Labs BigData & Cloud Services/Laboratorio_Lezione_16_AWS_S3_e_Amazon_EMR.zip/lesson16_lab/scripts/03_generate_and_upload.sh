#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
load_state
require_command aws
require_lab_bucket

DATA_FILE="${LAB_ROOT}/data/events_${DATASET_ROWS}.csv"
EXPECTED_FILE="${LAB_ROOT}/data/expected_${DATASET_ROWS}.json"
python3 "${LAB_ROOT}/scripts/generate_events.py" --rows "${DATASET_ROWS}" --output "${DATA_FILE}" --expected "${EXPECTED_FILE}"

aws s3 cp "${DATA_FILE}" "s3://${BUCKET_NAME}/input/events.csv" --only-show-errors
aws s3 cp "${EXPECTED_FILE}" "s3://${BUCKET_NAME}/input/expected.json" --only-show-errors
aws s3 cp "${LAB_ROOT}/job/dataflix_emr_job.py" "s3://${BUCKET_NAME}/code/dataflix_emr_job.py" --only-show-errors
save_state_value DATA_FILE "${DATA_FILE}"
save_state_value EXPECTED_FILE "${EXPECTED_FILE}"
echo "Asset caricati in s3://${BUCKET_NAME}/input e /code"

