#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
load_state
require_command aws
require_lab_bucket

if [[ -n "${RUNTIME_ROLE_ARN:-}" ]]; then
  save_state_value RUNTIME_ROLE_ARN "${RUNTIME_ROLE_ARN}"
  echo "Uso il ruolo già fornito: ${RUNTIME_ROLE_ARN}"
  exit 0
fi

ROLE_NAME="DataflixL16EMRRole-${LAB_SUFFIX}"
POLICY_NAME="DataflixL16S3Only"
POLICY_DIR="${LAB_ROOT}/build/iam-${LAB_SUFFIX}"
python3 "${LAB_ROOT}/scripts/render_iam_policies.py" --bucket "${BUCKET_NAME}" --output-dir "${POLICY_DIR}"

aws iam create-role --role-name "${ROLE_NAME}" \
  --assume-role-policy-document "file://${POLICY_DIR}/trust-policy.json" \
  --tags Key=Project,Value=DATAFLIX Key=Lesson,Value=16 Key=ManagedBy,Value=lab-script >/dev/null

aws iam put-role-policy --role-name "${ROLE_NAME}" --policy-name "${POLICY_NAME}" \
  --policy-document "file://${POLICY_DIR}/runtime-policy.json"

RUNTIME_ROLE_ARN="$(aws iam get-role --role-name "${ROLE_NAME}" --query Role.Arn --output text)"
save_state_value RUNTIME_ROLE_NAME "${ROLE_NAME}"
save_state_value RUNTIME_POLICY_NAME "${POLICY_NAME}"
save_state_value RUNTIME_ROLE_ARN "${RUNTIME_ROLE_ARN}"
echo "Creato ruolo least-privilege: ${RUNTIME_ROLE_ARN}"
echo "Se il comando iam:PassRole è negato al submit, il docente deve autorizzare questo ARN."

