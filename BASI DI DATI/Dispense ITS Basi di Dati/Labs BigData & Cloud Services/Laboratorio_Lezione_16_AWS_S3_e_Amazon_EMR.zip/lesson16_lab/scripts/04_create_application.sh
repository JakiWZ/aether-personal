#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
load_state
require_command aws

APP_NAME="dataflix-l16-${LAB_SUFFIX}"
APP_ID="$(aws emr-serverless create-application \
  --name "${APP_NAME}" \
  --release-label "${EMR_RELEASE_LABEL}" \
  --type SPARK \
  --auto-start-configuration enabled=true \
  --auto-stop-configuration enabled=true,idleTimeoutMinutes=5 \
  --maximum-capacity '{"cpu":"8 vCPU","memory":"32 GB","disk":"40 GB"}' \
  --tags Project=DATAFLIX,Lesson=16,ManagedBy=lab-script \
  --query applicationId --output text)"

save_state_value APP_NAME "${APP_NAME}"
save_state_value APP_ID "${APP_ID}"
save_state_value EMR_RELEASE_LABEL "${EMR_RELEASE_LABEL}"

for _ in $(seq 1 40); do
  STATE="$(aws emr-serverless get-application --application-id "${APP_ID}" --query application.state --output text)"
  echo "Application ${APP_ID}: ${STATE}"
  [[ "${STATE}" == "CREATED" ]] && exit 0
  [[ "${STATE}" == "TERMINATED" ]] && exit 1
  sleep 5
done
echo "Timeout in attesa dello stato CREATED" >&2
exit 1
