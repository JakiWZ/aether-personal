#!/usr/bin/env python3
"""Evidence gate: verifica stato, oggetti S3 e metriche del job cloud."""

from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def parse_env(path):
    result={}
    for line in path.read_text(encoding='utf-8').splitlines():
        if line and not line.startswith('#') and '=' in line:
            k,v=line.split('=',1); result[k]=v
    return result


def aws(*args):
    return subprocess.check_output(['aws',*args],text=True).strip()


def main():
    state_path=ROOT/'.dataflix-l16-state.env'
    if not state_path.exists(): raise SystemExit('EVIDENCE GATE: FALLITO — stato assente')
    s=parse_env(state_path); bucket=s['BUCKET_NAME']; prefix=s['RUN_PREFIX']; app=s['APP_ID']; job=s['JOB_RUN_ID']
    status=json.loads(aws('emr-serverless','get-job-run','--application-id',app,'--job-run-id',job,'--output','json'))['jobRun']
    objects=json.loads(aws('s3api','list-objects-v2','--bucket',bucket,'--prefix',f'{prefix}/output/','--output','json')).get('Contents',[])
    keys=[o['Key'] for o in objects]
    required=['curated_events/_SUCCESS','top_movies/_SUCCESS','country_minutes/_SUCCESS','metrics/_SUCCESS']
    billed=status.get('billedResourceUtilization',{})
    checks={'job SUCCESS':status['state']=='SUCCESS','billed resources registrate':bool(billed)}
    for item in required: checks[item]=any(k.endswith(item) for k in keys)

    metrics_keys=[k for k in keys if '/metrics/part-' in k and k.endswith('.json')]
    if len(metrics_keys)!=1: checks['un solo metrics part JSON']=False; metrics={}
    else:
        checks['un solo metrics part JSON']=True
        metrics_path=ROOT/'evidence/runtime/metrics.json'; metrics_path.parent.mkdir(parents=True,exist_ok=True)
        aws('s3api','get-object','--bucket',bucket,'--key',metrics_keys[0],str(metrics_path),'--query','ETag','--output','text')
        metrics=json.loads(metrics_path.read_text(encoding='utf-8'))
    expected_path=Path(s['EXPECTED_FILE']); expected=json.loads(expected_path.read_text(encoding='utf-8'))
    for name in ['raw_count','valid_count','invalid_count','top_movie_id','top_movie_count']:
        checks[name]=metrics.get(name)==expected[name]

    evidence={
        'region':s.get('AWS_REGION'),'bucket':bucket,'application_id':app,'job_run_id':job,
        'job_state':status.get('state'),'state_details':status.get('stateDetails'),
        'billed_resource_utilization':billed,
        'metrics':metrics,'checks':checks,
    }
    out=ROOT/'evidence/runtime/cloud-evidence.json'; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(evidence,indent=2),encoding='utf-8')
    for label,ok in checks.items(): print(f"[{'OK' if ok else 'NO'}] {label}")
    if not all(checks.values()): raise SystemExit('EVIDENCE GATE: FALLITO')
    print('EVIDENCE GATE: SUPERATO')


if __name__=='__main__': main()
