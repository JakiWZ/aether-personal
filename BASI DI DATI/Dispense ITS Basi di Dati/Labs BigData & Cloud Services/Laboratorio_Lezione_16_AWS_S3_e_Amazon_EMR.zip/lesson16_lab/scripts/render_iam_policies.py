#!/usr/bin/env python3
"""Genera trust e permissions policy limitate al bucket del laboratorio."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--bucket', required=True)
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    if not args.bucket.startswith('dataflix-l16-'):
        raise SystemExit('Bucket rifiutato: prefisso inatteso')
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    trust = {
        'Version': '2012-10-17',
        'Statement': [{
            'Effect': 'Allow',
            'Principal': {'Service': 'emr-serverless.amazonaws.com'},
            'Action': 'sts:AssumeRole',
        }],
    }
    permissions = {
        'Version': '2012-10-17',
        'Statement': [
            {
                'Sid': 'ListOnlyTheLabBucket',
                'Effect': 'Allow',
                'Action': ['s3:ListBucket', 's3:GetBucketLocation'],
                'Resource': [f'arn:aws:s3:::{args.bucket}'],
            },
            {
                'Sid': 'ReadWriteOnlyLabObjects',
                'Effect': 'Allow',
                'Action': ['s3:GetObject', 's3:PutObject', 's3:DeleteObject'],
                'Resource': [f'arn:aws:s3:::{args.bucket}/*'],
            },
        ],
    }
    (out/'trust-policy.json').write_text(json.dumps(trust, indent=2), encoding='utf-8')
    (out/'runtime-policy.json').write_text(json.dumps(permissions, indent=2), encoding='utf-8')
    print(out/'trust-policy.json')
    print(out/'runtime-policy.json')


if __name__ == '__main__':
    main()

