#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
require_command aws

ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
LAB_SUFFIX="$(date -u +%Y%m%d%H%M%S)"
BUCKET_NAME="dataflix-l16-${ACCOUNT_ID}-${LAB_SUFFIX}"

if [[ "${AWS_REGION}" == "us-east-1" ]]; then
  aws s3api create-bucket --bucket "${BUCKET_NAME}" --region "${AWS_REGION}" >/dev/null
else
  aws s3api create-bucket --bucket "${BUCKET_NAME}" --region "${AWS_REGION}" \
    --create-bucket-configuration "LocationConstraint=${AWS_REGION}" >/dev/null
fi

aws s3api put-public-access-block --bucket "${BUCKET_NAME}" --public-access-block-configuration \
  BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

aws s3api put-bucket-encryption --bucket "${BUCKET_NAME}" --server-side-encryption-configuration \
  '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

aws s3api put-bucket-tagging --bucket "${BUCKET_NAME}" --tagging \
  'TagSet=[{Key=Project,Value=DATAFLIX},{Key=Course,Value=BigDataCloud},{Key=Lesson,Value=16},{Key=ManagedBy,Value=lab-script}]'

aws s3api put-bucket-lifecycle-configuration --bucket "${BUCKET_NAME}" --lifecycle-configuration \
  '{"Rules":[{"ID":"expire-lab-objects-after-7-days","Status":"Enabled","Filter":{"Prefix":""},"Expiration":{"Days":7},"AbortIncompleteMultipartUpload":{"DaysAfterInitiation":1}}]}'

save_state_value AWS_ACCOUNT_ID "${ACCOUNT_ID}"
save_state_value LAB_SUFFIX "${LAB_SUFFIX}"
save_state_value BUCKET_NAME "${BUCKET_NAME}"
save_state_value AWS_REGION "${AWS_REGION}"
save_state_value AWS_PROFILE "${AWS_PROFILE}"
echo "Creato bucket protetto: ${BUCKET_NAME}"
