#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path


def main():
    p=argparse.ArgumentParser(); p.add_argument('--bucket',required=True); p.add_argument('--run-prefix',required=True); p.add_argument('--output-dir',required=True); a=p.parse_args()
    if not a.bucket.startswith('dataflix-l16-') or not a.run_prefix.startswith('runs/'):
        raise SystemExit('Target rifiutato')
    out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    driver={'sparkSubmit':{
        'entryPoint':f's3://{a.bucket}/code/dataflix_emr_job.py',
        'entryPointArguments':['--input',f's3://{a.bucket}/input/events.csv','--output',f's3://{a.bucket}/{a.run_prefix}/output'],
        'sparkSubmitParameters':'--conf spark.driver.cores=1 --conf spark.driver.memory=4g --conf spark.executor.cores=2 --conf spark.executor.memory=4g --conf spark.executor.instances=2 --conf spark.sql.shuffle.partitions=8 --conf spark.sql.session.timeZone=UTC'
    }}
    overrides={'monitoringConfiguration':{
        'managedPersistenceMonitoringConfiguration':{'enabled':True},
        's3MonitoringConfiguration':{'logUri':f's3://{a.bucket}/{a.run_prefix}/logs/'},
    }}
    (out/'job-driver.json').write_text(json.dumps(driver,indent=2),encoding='utf-8')
    (out/'configuration-overrides.json').write_text(json.dumps(overrides,indent=2),encoding='utf-8')


if __name__=='__main__': main()

