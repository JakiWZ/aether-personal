#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
require_command aws
require_command python3

echo "== Versioni =="
aws --version
python3 --version

echo "== Identità chiamante =="
aws sts get-caller-identity --output table

echo "== Regione e servizio =="
aws emr-serverless list-applications --max-results 1 --region "${AWS_REGION}" >/dev/null
echo "Preflight completato nella regione ${AWS_REGION}."

