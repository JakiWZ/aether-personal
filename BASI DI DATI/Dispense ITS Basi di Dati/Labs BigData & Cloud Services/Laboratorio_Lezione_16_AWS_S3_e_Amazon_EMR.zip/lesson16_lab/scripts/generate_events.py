#!/usr/bin/env python3
"""Genera eventi DATAFLIX deterministici per il laboratorio cloud."""

from __future__ import annotations

import argparse
import csv
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

HEADER=['event_id','user_id','movie_id','event_ts','duration_seconds','country','device','quality','event_type','subscription_plan']
COUNTRIES=['IT','DE','FR','ES','US','BR','JP']; WEIGHTS=[24,16,14,12,18,9,7]
DEVICES=['mobile','tv','web','tablet']; QUALITIES=['SD','HD','FHD','4K']; PLANS=['basic','standard','premium']


def movie(i, rng):
    b=i%100
    if b<8: return 'MOV-0042'
    if b<13: return 'MOV-0007'
    if b<17: return 'MOV-0314'
    return f'MOV-{1000+rng.randrange(2000):04d}'


def dirty(offset):
    base=['EVT-DIRTY','USR-999999','MOV-1999','2026-08-01 12:00:00','180','IT','web','HD','play','standard']
    result=[]
    for j in range(5): r=base.copy(); r[0]=f'EVT-D{offset+j}'; r[4]='not_an_int'; result.append(r)
    for j in range(5,10): r=base.copy(); r[0]=f'EVT-D{offset+j}'; r[3]='31/08/2026'; result.append(r)
    for j in range(10,15): r=base.copy(); r[0]=f'EVT-D{offset+j}'; r[5]=''; result.append(r)
    for j in range(15,20): r=base.copy(); r[0]=f'EVT-D{offset+j}'; r[8]='teleport'; result.append(r)
    return result


def main():
    p=argparse.ArgumentParser(); p.add_argument('--rows',type=int,default=200000); p.add_argument('--seed',type=int,default=16016)
    p.add_argument('--output',required=True); p.add_argument('--expected',required=True); a=p.parse_args()
    if a.rows<1000 or a.rows>1_000_000: raise SystemExit('rows deve essere fra 1.000 e 1.000.000')
    out=Path(a.output); exp=Path(a.expected); out.parent.mkdir(parents=True,exist_ok=True); exp.parent.mkdir(parents=True,exist_ok=True)
    rng=random.Random(a.seed); start=datetime(2026,8,1)
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(HEADER)
        for i in range(a.rows):
            kind=['play']*6+['pause']*2+['complete','error']; event=kind[i%10]
            duration=0 if event=='error' else rng.randint(1,120) if event=='pause' else rng.randint(30,7200)
            ts=start+timedelta(days=i%30,seconds=(i*37)%86400)
            w.writerow([f'EVT-{i:09d}',f'USR-{1+rng.randrange(50000):06d}',movie(i,rng),ts.strftime('%Y-%m-%d %H:%M:%S'),duration,
                        rng.choices(COUNTRIES,weights=WEIGHTS,k=1)[0],DEVICES[(i*7)%4],QUALITIES[(i*11)%4],event,PLANS[(i*5)%3]])
        w.writerows(dirty(a.rows))
    exp.write_text(json.dumps({'raw_count':a.rows+20,'valid_count':a.rows,'invalid_count':20,'top_movie_id':'MOV-0042','top_movie_count':a.rows*8//100,'seed':a.seed},indent=2),encoding='utf-8')
    print(f'Creato {out} con {a.rows+20:,} righe dati')


if __name__=='__main__': main()

