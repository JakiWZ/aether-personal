#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
load_config
load_state
require_command aws
: "${APP_ID:?APP_ID mancante}"; : "${JOB_RUN_ID:?JOB_RUN_ID mancante}"

FINAL_STATE=""
for _ in $(seq 1 120); do
  FINAL_STATE="$(aws emr-serverless get-job-run --application-id "${APP_ID}" --job-run-id "${JOB_RUN_ID}" --query jobRun.state --output text)"
  echo "Job ${JOB_RUN_ID}: ${FINAL_STATE}"
  case "${FINAL_STATE}" in
    SUCCESS|FAILED|CANCELLED) break ;;
  esac
  sleep 15
done
save_state_value JOB_FINAL_STATE "${FINAL_STATE}"

mkdir -p "${LAB_ROOT}/evidence/runtime"
aws emr-serverless get-job-run --application-id "${APP_ID}" --job-run-id "${JOB_RUN_ID}" \
  --output json > "${LAB_ROOT}/evidence/runtime/job-run.json"
aws s3 ls "s3://${BUCKET_NAME}/${RUN_PREFIX}/" --recursive > "${LAB_ROOT}/evidence/runtime/s3-tree.txt"

if [[ "${FINAL_STATE}" != "SUCCESS" ]]; then
  echo "Job non riuscito. Controlla stateDetails e i log in S3." >&2
  exit 1
fi
echo "Job completato. Evidenze runtime raccolte."

