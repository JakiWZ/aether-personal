#!/usr/bin/env python3
"""Starter: completa gli esercizi indicati prima di confrontarti con la soluzione."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from pyspark import StorageLevel
from pyspark.sql import SparkSession, functions as F, types as T


def arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--hold-seconds", type=int, default=0)
    return parser.parse_args()


def main():
    args = arguments()
    spark = (
        SparkSession.builder.appName("DATAFLIX-L15-Student")
        .config("spark.sql.shuffle.partitions", "8")
        .config("spark.sql.session.timeZone", "UTC")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")

    # ESERCIZIO 1 — Dichiarare dieci campi raw come StringType.
    raw_schema = T.StructType([
        T.StructField("event_id_raw", T.StringType()),
        # Aggiungi qui gli altri nove campi nello stesso ordine del CSV.
    ])

    raw = (
        spark.read.option("header", True).option("mode", "PERMISSIVE")
        .schema(raw_schema).csv(args.input)
    )
    raw.printSchema()

    # ESERCIZIO 2 — Costruire `parsed` con trim, normalizzazione,
    # try_to_timestamp e try_cast. Non usare un UDF Python.
    parsed = raw

    # ESERCIZIO 3 — Filtrare campi obbligatori e domini validi;
    # aggiungere event_date. Il risultato deve chiamarsi `curated`.
    curated = parsed

    # ESERCIZIO 4 — Persistenza: applica MEMORY_AND_DISK e materializzala
    # con un'azione. Calcola raw_count, valid_count e invalid_count.
    raw_count = raw.count()
    curated = curated.persist(StorageLevel.MEMORY_AND_DISK)
    valid_count = curated.count()
    invalid_count = raw_count - valid_count
    print(json.dumps({"raw": raw_count, "valid": valid_count, "invalid": invalid_count}, indent=2))

    # ESERCIZIO 5 — Aggrega per movie_id: events e seconds.
    # Ordina per events decrescente e poi movie_id crescente.
    top_movies = curated.groupBy("movie_id").count()
    top_movies.explain(mode="formatted")

    # ESERCIZIO 6 — Crea almeno altre due aggregazioni:
    # country_minutes e daily_trend. Individua lo shuffle nel piano.

    # ESERCIZIO 7 — Scrivi top_movies e curated_events in Parquet.
    # Prima di curated_events usa repartition(8, "event_date") e poi
    # partitionBy("event_date").
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)

    # ESERCIZIO 8 — Registra la view `events` ed esegui in Spark SQL
    # la stessa top 10. Verifica che le due liste coincidano.

    # ESERCIZIO 9 — Salva un piccolo summary JSON in output/evidence.
    # Non usare collect() sul dataset completo.

    if args.hold_seconds > 0:
        print(f"Osserva http://localhost:4040 per {args.hold_seconds} secondi")
        time.sleep(args.hold_seconds)
    curated.unpersist()
    spark.stop()


if __name__ == "__main__":
    main()

