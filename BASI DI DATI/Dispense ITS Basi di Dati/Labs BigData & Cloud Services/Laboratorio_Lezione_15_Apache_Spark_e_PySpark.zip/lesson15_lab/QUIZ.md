# Quiz finale — Apache Spark e PySpark

1. Quale componente contiene il `SparkContext` e coordina l'applicazione?
   - A. Executor
   - B. Driver
   - C. DataNode
   - D. Metastore

2. Quale istruzione avvia normalmente il calcolo?
   - A. `select`
   - B. `filter`
   - C. `count`
   - D. `withColumn`

3. Perché `groupBy` è spesso una trasformazione wide?
   - A. Cambia lo schema
   - B. Richiede dati della stessa chiave sulla stessa partizione
   - C. Usa sempre SQL
   - D. Scrive Parquet

4. Che cosa rappresenta un task?
   - A. L'intera applicazione
   - B. Un'unità di lavoro su una partizione dentro uno stage
   - C. Un file HDFS
   - D. Una tabella

5. Quando è sensato usare `cache()`?
   - A. Sempre dopo una lettura
   - B. Quando lo stesso DataFrame costoso verrà riutilizzato
   - C. Solo prima di `show()`
   - D. Per sostituire Parquet

6. Qual è il rischio di `collect()`?
   - A. Duplica le colonne
   - B. Porta tutti i record nel driver e può esaurirne la memoria
   - C. Cancella la lineage
   - D. Impedisce lo shuffle

7. Che cosa mostra `explain("formatted")`?
   - A. Soltanto il codice Python
   - B. Il piano di esecuzione organizzato per operatori
   - C. La cronologia Git
   - D. I log di Docker

8. `repartition(8, "event_date")` comporta normalmente:
   - A. uno shuffle
   - B. nessuna esecuzione possibile
   - C. una raccolta sul driver
   - D. una join broadcast

9. Perché le funzioni Spark built-in sono preferibili a una UDF Python quando possibile?
   - A. Sono sempre più brevi
   - B. Il motore può comprenderle e ottimizzarle meglio
   - C. Non usano memoria
   - D. Evitano ogni job

10. Quale affermazione è corretta?
   - A. Spark è un database
   - B. Spark richiede che tutti i dati restino sempre in RAM
   - C. Spark è un motore di elaborazione che può leggere più storage
   - D. Un'azione non produce mai job

## Soluzioni

1B, 2C, 3B, 4B, 5B, 6B, 7B, 8A, 9B, 10C.

