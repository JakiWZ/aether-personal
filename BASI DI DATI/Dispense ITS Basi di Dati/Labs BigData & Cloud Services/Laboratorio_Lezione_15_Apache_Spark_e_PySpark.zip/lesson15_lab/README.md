# Laboratorio 15 — Spark e PySpark: un milione di eventi DATAFLIX

Durata: **150 minuti**. Modalità: coppie. Obiettivo: costruire e verificare una pipeline DataFrame, collegando codice, DAG, partizioni, shuffle, cache e piano fisico.

## Risultato atteso

Al termine avrai:

- generato `1.000.000` eventi validi e `20` righe deliberatamente non valide;
- applicato uno schema esplicito e un quality gate;
- prodotto cinque aggregazioni e un dataset Parquet partizionato;
- osservato job, stage e SQL nella Spark UI;
- confrontato trasformazioni narrow e wide con `explain("formatted")`;
- superato un evidence gate automatico.

## Prerequisiti

- Docker Desktop o Docker Engine con Compose v2;
- almeno 4 GB di RAM disponibili a Docker;
- porte locali 4040 e 4041 libere;
- terminale Bash. Su Windows usare WSL 2 oppure Git Bash.

L'immagine è quella ufficiale Apache Spark. Al primo avvio il download può richiedere alcuni minuti.

## Avvio rapido

```bash
docker compose up -d
docker compose exec spark python3 scripts/generate_events.py \
  --rows 1000000 \
  --output data/events_1000000.csv \
  --expected data/expected_1000000.json
```

Verifica che il container sia pronto:

```bash
docker compose ps
docker compose exec spark /opt/spark/bin/spark-submit --version
```

Per una prova veloce è già incluso `data/sample_events.csv`.

## Percorso di 150 minuti

| Minuti | Fase | Evidenza |
|---:|---|---|
| 0–15 | Avvio, versione e dataset | conteggio righe e schema del CSV |
| 15–35 | SparkSession, schema raw, parsing | `printSchema()` e conteggi raw/valid/invalid |
| 35–60 | Trasformazioni e azioni | annotazioni in `evidence/observations.md` |
| 60–85 | Aggregazioni e shuffle | piano `explain("formatted")` |
| 85–105 | Partizioni, Parquet e pruning | cartelle `event_date=...` |
| 105–120 | Cache e riuso | scheda Storage nella Spark UI |
| 120–135 | Spark SQL e equivalenza | risultato DataFrame = risultato SQL |
| 135–150 | Evidence gate e retrospettiva | `EVIDENCE GATE: SUPERATO` |

## Parte A — Starter

Apri `src/student_pipeline.py` e completa gli esercizi numerati. Esegui così:

```bash
docker compose exec spark /opt/spark/bin/spark-submit \
  --master local[4] \
  --conf spark.ui.port=4040 \
  src/student_pipeline.py \
  --input data/events_1000000.csv \
  --output output_student \
  --hold-seconds 120
```

Durante la pausa finale apri <http://localhost:4040>. Cerca:

1. quanti job sono stati creati dalle azioni;
2. quale stage contiene uno `Exchange` o uno shuffle;
3. se il DataFrame curato è presente nella scheda Storage;
4. quante partizioni e task vengono usati.

## Parte B — Soluzione di confronto

Usala dopo il tentativo autonomo:

```bash
docker compose exec spark /opt/spark/bin/spark-submit \
  --master local[4] \
  --conf spark.ui.port=4040 \
  solution/dataflix_pipeline_solution.py \
  --input data/events_1000000.csv \
  --output output_solution \
  --hold-seconds 120
```

La soluzione salva:

- `curated_events/` in Parquet, partizionato per `event_date`;
- `top_movies/`, `country_minutes/`, `device_quality/`, `daily_trend/` e `plan_engagement/`;
- `evidence/summary.json`;
- `evidence/explain_formatted.txt`;
- `evidence/sql_equivalence.json`.

## Evidence gate

```bash
docker compose exec spark python3 scripts/verify_output.py \
  --output output_solution \
  --expected data/expected_1000000.json
```

Per superarlo devono essere vere tutte queste condizioni:

- `raw_count = 1.000.020`;
- `valid_count = 1.000.000` e `invalid_count = 20`;
- il film più frequente è `MOV-0042` con `80.000` eventi;
- gli output Parquet hanno il file `_SUCCESS`;
- DataFrame API e Spark SQL restituiscono la stessa top 10;
- piano e osservazioni sono presenti.

## Challenge

Senza modificare il generatore, trova **tre insight non richiesti**. Per ciascuno scrivi in `evidence/observations.md`:

1. la domanda;
2. la trasformazione PySpark;
3. se introduce uno shuffle e perché;
4. il risultato;
5. un limite interpretativo.

## Debrief

- Quale riga del codice è una trasformazione? Quale è un'azione?
- Perché `groupBy` separa due stage?
- Quando la cache ha evitato lavoro e quando lo ha soltanto rinviato?
- Perché `collect()` è accettabile sulla top 10 ma non sul dataset completo?
- Che cosa cambierebbe passando da `local[4]` a un cluster?

## Pulizia

```bash
docker compose down
```

Gli output restano nella cartella del laboratorio e possono essere rimossi manualmente dopo la consegna.

