#!/usr/bin/env python3
"""Soluzione completa del laboratorio DATAFLIX con PySpark DataFrame e SQL."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import time
from pathlib import Path

from pyspark import StorageLevel
from pyspark.sql import SparkSession, functions as F, types as T


RAW_SCHEMA = T.StructType([
    T.StructField("event_id_raw", T.StringType()),
    T.StructField("user_id_raw", T.StringType()),
    T.StructField("movie_id_raw", T.StringType()),
    T.StructField("event_ts_raw", T.StringType()),
    T.StructField("duration_seconds_raw", T.StringType()),
    T.StructField("country_raw", T.StringType()),
    T.StructField("device_raw", T.StringType()),
    T.StructField("quality_raw", T.StringType()),
    T.StructField("event_type_raw", T.StringType()),
    T.StructField("subscription_plan_raw", T.StringType()),
])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--hold-seconds", type=int, default=0)
    return parser.parse_args()


def build_curated(raw):
    parsed = raw.select(
        F.trim("event_id_raw").alias("event_id"),
        F.trim("user_id_raw").alias("user_id"),
        F.trim("movie_id_raw").alias("movie_id"),
        F.expr("try_to_timestamp(event_ts_raw, 'yyyy-MM-dd HH:mm:ss')").alias("event_ts"),
        F.expr("try_cast(duration_seconds_raw AS INT)").alias("duration_seconds"),
        F.upper(F.trim("country_raw")).alias("country"),
        F.lower(F.trim("device_raw")).alias("device"),
        F.upper(F.trim("quality_raw")).alias("quality"),
        F.lower(F.trim("event_type_raw")).alias("event_type"),
        F.lower(F.trim("subscription_plan_raw")).alias("subscription_plan"),
    )
    required = (
        F.col("event_id").isNotNull()
        & F.col("user_id").isNotNull()
        & F.col("movie_id").isNotNull()
        & F.col("event_ts").isNotNull()
        & F.col("duration_seconds").isNotNull()
        & F.col("country").isNotNull()
        & (F.length("country") > 0)
    )
    domains = (
        F.col("duration_seconds").between(0, 28_800)
        & F.col("event_type").isin("play", "pause", "complete", "error")
        & F.col("device").isin("mobile", "tv", "web", "tablet")
        & F.col("quality").isin("SD", "HD", "FHD", "4K")
        & F.col("subscription_plan").isin("basic", "standard", "premium")
    )
    return parsed.filter(required & domains).withColumn("event_date", F.to_date("event_ts"))


def capture_explain(frame) -> str:
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream):
        frame.explain(mode="formatted")
    return stream.getvalue()


def main() -> None:
    args = parse_args()
    out = Path(args.output)
    evidence = out / "evidence"
    evidence.mkdir(parents=True, exist_ok=True)

    spark = (
        SparkSession.builder
        .appName("DATAFLIX-L15-Solution")
        .config("spark.sql.shuffle.partitions", "8")
        .config("spark.sql.session.timeZone", "UTC")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")

    raw = (
        spark.read
        .option("header", True)
        .option("mode", "PERMISSIVE")
        .schema(RAW_SCHEMA)
        .csv(args.input)
    )
    raw_count = raw.count()
    curated = build_curated(raw).persist(StorageLevel.MEMORY_AND_DISK)
    valid_count = curated.count()  # prima azione: materializza la cache
    invalid_count = raw_count - valid_count

    top_movies = (
        curated.groupBy("movie_id")
        .agg(F.count("*").alias("events"), F.sum("duration_seconds").alias("seconds"))
        .orderBy(F.desc("events"), F.asc("movie_id"))
    )
    country_minutes = (
        curated.groupBy("country")
        .agg(
            F.round(F.sum("duration_seconds") / F.lit(60.0), 2).alias("minutes"),
            F.countDistinct("user_id").alias("active_users"),
        )
        .orderBy(F.desc("minutes"))
    )
    device_quality = (
        curated.groupBy("device", "quality")
        .agg(F.count("*").alias("events"), F.round(F.avg("duration_seconds"), 2).alias("avg_seconds"))
        .orderBy("device", "quality")
    )
    daily_trend = (
        curated.groupBy("event_date")
        .agg(F.count("*").alias("events"), F.sum("duration_seconds").alias("seconds"))
        .orderBy("event_date")
    )
    plan_engagement = (
        curated.groupBy("subscription_plan")
        .agg(
            F.count("*").alias("events"),
            F.countDistinct("user_id").alias("users"),
            F.round(F.avg("duration_seconds"), 2).alias("avg_seconds"),
        )
        .orderBy(F.desc("avg_seconds"))
    )

    explain_text = capture_explain(top_movies)
    (evidence / "explain_formatted.txt").write_text(explain_text, encoding="utf-8")
    print(explain_text)

    top_movies.write.mode("overwrite").parquet(str(out / "top_movies"))
    country_minutes.write.mode("overwrite").parquet(str(out / "country_minutes"))
    device_quality.write.mode("overwrite").parquet(str(out / "device_quality"))
    daily_trend.write.mode("overwrite").parquet(str(out / "daily_trend"))
    plan_engagement.write.mode("overwrite").parquet(str(out / "plan_engagement"))
    (
        curated.repartition(8, "event_date")
        .write.mode("overwrite")
        .partitionBy("event_date")
        .parquet(str(out / "curated_events"))
    )

    curated.createOrReplaceTempView("events")
    sql_top = spark.sql("""
        SELECT movie_id, COUNT(*) AS events
        FROM events
        GROUP BY movie_id
        ORDER BY events DESC, movie_id ASC
        LIMIT 10
    """)
    df_top = top_movies.select("movie_id", "events").limit(10)
    sql_rows = [row.asDict(recursive=True) for row in sql_top.collect()]
    df_rows = [row.asDict(recursive=True) for row in df_top.collect()]
    sql_equivalent = sql_rows == df_rows
    (evidence / "sql_equivalence.json").write_text(json.dumps({
        "equivalent": sql_equivalent,
        "dataframe_top10": df_rows,
        "sql_top10": sql_rows,
    }, indent=2, default=str), encoding="utf-8")

    top_five = [row.asDict(recursive=True) for row in top_movies.limit(5).collect()]
    summary = {
        "spark_version": spark.version,
        "master": spark.sparkContext.master,
        "raw_count": raw_count,
        "valid_count": valid_count,
        "invalid_count": invalid_count,
        "input_partitions": raw.rdd.getNumPartitions(),
        "cached_partitions": curated.rdd.getNumPartitions(),
        "shuffle_partitions": int(spark.conf.get("spark.sql.shuffle.partitions")),
        "top_movies": top_five,
        "sql_equivalent": sql_equivalent,
    }
    (evidence / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    print(json.dumps(summary, indent=2, default=str))

    curated.unpersist()
    if args.hold_seconds > 0:
        print(f"Spark UI disponibile su http://localhost:4040 per {args.hold_seconds} secondi")
        time.sleep(args.hold_seconds)
    spark.stop()


if __name__ == "__main__":
    main()

