#!/usr/bin/env python3
"""Genera un dataset DATAFLIX deterministico con un piccolo insieme di errori."""

from __future__ import annotations

import argparse
import csv
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

HEADER = [
    "event_id", "user_id", "movie_id", "event_ts", "duration_seconds",
    "country", "device", "quality", "event_type", "subscription_plan",
]

COUNTRIES = ["IT", "DE", "FR", "ES", "US", "BR", "JP"]
COUNTRY_WEIGHTS = [24, 16, 14, 12, 18, 9, 7]
DEVICES = ["mobile", "tv", "web", "tablet"]
QUALITIES = ["SD", "HD", "FHD", "4K"]
PLANS = ["basic", "standard", "premium"]
EVENTS = ["play"] * 6 + ["pause"] * 2 + ["complete", "error"]


def movie_for(i: int, rng: random.Random) -> str:
    bucket = i % 100
    if bucket < 8:
        return "MOV-0042"
    if bucket < 13:
        return "MOV-0007"
    if bucket < 17:
        return "MOV-0314"
    return f"MOV-{1000 + rng.randrange(2000):04d}"


def valid_row(i: int, rng: random.Random, start: datetime) -> list[str]:
    event_type = EVENTS[i % len(EVENTS)]
    if event_type == "error":
        duration = 0
    elif event_type == "pause":
        duration = rng.randint(1, 120)
    else:
        duration = rng.randint(30, 7200)
    ts = start + timedelta(days=i % 30, seconds=(i * 37) % 86400)
    return [
        f"EVT-{i:09d}",
        f"USR-{1 + rng.randrange(120000):06d}",
        movie_for(i, rng),
        ts.strftime("%Y-%m-%d %H:%M:%S"),
        str(duration),
        rng.choices(COUNTRIES, weights=COUNTRY_WEIGHTS, k=1)[0],
        DEVICES[(i * 7) % len(DEVICES)],
        QUALITIES[(i * 11) % len(QUALITIES)],
        event_type,
        PLANS[(i * 5) % len(PLANS)],
    ]


def dirty_rows(offset: int) -> list[list[str]]:
    rows = []
    base = [
        "EVT-DIRTY", "USR-999999", "MOV-1999", "2026-08-01 12:00:00", "180",
        "IT", "web", "HD", "play", "standard",
    ]
    for j in range(5):
        row = base.copy(); row[0] = f"EVT-D{offset+j:04d}"; row[4] = "not_an_int"; rows.append(row)
    for j in range(5, 10):
        row = base.copy(); row[0] = f"EVT-D{offset+j:04d}"; row[3] = "31/08/2026"; rows.append(row)
    for j in range(10, 15):
        row = base.copy(); row[0] = f"EVT-D{offset+j:04d}"; row[5] = ""; rows.append(row)
    for j in range(15, 20):
        row = base.copy(); row[0] = f"EVT-D{offset+j:04d}"; row[8] = "teleport"; rows.append(row)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=1_000_000)
    parser.add_argument("--seed", type=int, default=15015)
    parser.add_argument("--output", required=True)
    parser.add_argument("--expected", required=True)
    args = parser.parse_args()
    if args.rows < 100:
        raise SystemExit("--rows deve essere almeno 100")

    output = Path(args.output)
    expected = Path(args.expected)
    output.parent.mkdir(parents=True, exist_ok=True)
    expected.parent.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)
    start = datetime(2026, 8, 1)

    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(HEADER)
        for i in range(args.rows):
            writer.writerow(valid_row(i, rng, start))
        writer.writerows(dirty_rows(args.rows))

    expected.write_text(json.dumps({
        "requested_valid_rows": args.rows,
        "raw_count": args.rows + 20,
        "valid_count": args.rows,
        "invalid_count": 20,
        "top_movie_id": "MOV-0042",
        "top_movie_count": args.rows * 8 // 100,
        "seed": args.seed,
    }, indent=2), encoding="utf-8")
    print(f"Creato {output}: {args.rows + 20:,} righe dati")
    print(f"Contratto atteso: {expected}")


if __name__ == "__main__":
    main()

