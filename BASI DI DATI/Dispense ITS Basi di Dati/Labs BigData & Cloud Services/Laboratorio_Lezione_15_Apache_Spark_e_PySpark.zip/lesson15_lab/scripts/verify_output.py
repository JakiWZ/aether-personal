#!/usr/bin/env python3
"""Evidence gate indipendente dal job Spark."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--expected", required=True)
    args = parser.parse_args()
    out = Path(args.output)
    expected = json.loads(Path(args.expected).read_text(encoding="utf-8"))
    summary_path = out / "evidence" / "summary.json"
    if not summary_path.exists():
        raise SystemExit("EVIDENCE GATE: FALLITO — manca evidence/summary.json")
    summary = json.loads(summary_path.read_text(encoding="utf-8"))

    checks = {
        "conteggio raw": summary.get("raw_count") == expected["raw_count"],
        "conteggio validi": summary.get("valid_count") == expected["valid_count"],
        "conteggio invalidi": summary.get("invalid_count") == expected["invalid_count"],
        "SQL equivalente": summary.get("sql_equivalent") is True,
        "film top": bool(summary.get("top_movies"))
            and summary["top_movies"][0].get("movie_id") == expected["top_movie_id"],
        "conteggio film top": bool(summary.get("top_movies"))
            and summary["top_movies"][0].get("events") == expected["top_movie_count"],
        "piano presente": (out / "evidence" / "explain_formatted.txt").stat().st_size > 100,
        "equivalenza presente": (out / "evidence" / "sql_equivalence.json").exists(),
    }
    for folder in ["curated_events", "top_movies", "country_minutes", "device_quality", "daily_trend", "plan_engagement"]:
        checks[f"_SUCCESS {folder}"] = (out / folder / "_SUCCESS").exists()

    for label, passed in checks.items():
        print(f"[{'OK' if passed else 'NO'}] {label}")
    if not all(checks.values()):
        raise SystemExit("EVIDENCE GATE: FALLITO")
    print("EVIDENCE GATE: SUPERATO")


if __name__ == "__main__":
    main()

