# Osservazioni — Lezione 15

## UI

- Numero di job osservati:
- Stage con shuffle:
- Partizioni/task osservati:
- Stato della cache nella scheda Storage:

## Piano

- Operatore che dimostra lo shuffle:
- Filtro o proiezione spinta verso la scansione:
- Differenza tra piano logico e piano fisico:

## Tre insight autonomi

### Insight 1

- Domanda:
- Trasformazione:
- Shuffle sì/no e perché:
- Risultato:
- Limite interpretativo:

### Insight 2

- Domanda:
- Trasformazione:
- Shuffle sì/no e perché:
- Risultato:
- Limite interpretativo:

### Insight 3

- Domanda:
- Trasformazione:
- Shuffle sì/no e perché:
- Risultato:
- Limite interpretativo:

