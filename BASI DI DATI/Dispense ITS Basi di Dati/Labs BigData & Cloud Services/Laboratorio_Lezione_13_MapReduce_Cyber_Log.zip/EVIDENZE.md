# Evidenze — Cyber Log MapReduce

## Gruppo

- Componenti:
- Data:
- Postazione:

## Evidence gate A — Cluster

- DataNode live:
- NodeManager RUNNING:
- Versione Python sui NodeManager:
- Osservazione:

## Evidence gate B — Test locale

- Esito validazione:
- Numero di key:
- Osservazione:

## Evidence gate C — HDFS

- Path input:
- Dimensione:
- Otto campi verificati:

## Evidence gate D — Job distribuito

- ApplicationId:
- Stato finale:
- Map task:
- Reduce task:
- NodeManager usati:
- Counter DATAFLIX/MalformedLines:
- Part file:
- Esito validazione distribuita:

## Insight 1

- Domanda:
- Comando/codice:
- Risultato:
- Interpretazione:
- Limite:

## Insight 2

- Domanda:
- Comando/codice:
- Risultato:
- Interpretazione:
- Limite:

## Insight 3

- Domanda:
- Comando/codice:
- Risultato:
- Interpretazione:
- Limite:

## Risposte finali

### Perché lo shuffle richiede rete?


### Perché un Reducer può diventare il collo di bottiglia?


