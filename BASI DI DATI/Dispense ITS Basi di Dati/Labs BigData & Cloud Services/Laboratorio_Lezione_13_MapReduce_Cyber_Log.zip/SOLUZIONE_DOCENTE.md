# Soluzione docente — Cyber Log MapReduce

## Esito atteso

Il laboratorio deve dimostrare tre cose distinte:

1. il contratto Mapper/Reducer è corretto localmente;
2. Hadoop orchestra lo stesso contratto su HDFS/YARN;
3. stato `SUCCEEDED`, counter e output numerico sono evidenze complementari.

Il dataset contiene 50.000 record validi e tre record malformati. Per ogni record valido il mapper emette quattro metriche base; per ogni status 5xx emette anche `ERROR_PATH`. I record malformati non producono metriche e incrementano il counter custom.

## Preparazione prima della lezione

```bash
python3 scripts/generate_logs.py
python3 jobs/mapper_metrics.py < data/access_logs.tsv \
  | LC_ALL=C sort \
  | python3 jobs/reducer_sum.py \
  > data/expected_metrics.tsv
python3 scripts/validate_metrics.py data/expected_metrics.tsv data/expected_metrics.tsv
```

Avviare il cluster una volta prima dell'aula, verificare le sei porte e scaricare in anticipo l'immagine `apache/hadoop:3.5.0`.

## Controlli rapidi

```bash
docker compose up -d
docker compose exec namenode hdfs dfsadmin -report
docker compose exec resourcemanager yarn node -list
docker compose exec nodemanager1 python3 --version
docker compose exec nodemanager2 python3 --version
```

Attesi:

- un DataNode live;
- due NodeManager `RUNNING`;
- Python 3 in entrambi i container compute.

Se i NodeManager non compaiono subito, attendere alcuni secondi e leggere:

```bash
docker compose logs --tail=120 resourcemanager nodemanager1 nodemanager2
```

## Perché il test locale viene prima

La pipeline locale elimina HDFS, YARN, container allocation e rete. Se fallisce, il difetto è nel contratto dei due script o nei dati. Se passa localmente e fallisce sul cluster, la ricerca si sposta su distribuzione dei file, interprete Python, configurazione o risorse.

Il comando `sort` è indispensabile: il reducer mantiene una sola key corrente e presume l'input raggruppato, esattamente come nel runtime MapReduce.

## Job distribuito di riferimento

```bash
docker compose exec namenode hdfs dfs -mkdir -p /dataflix/input
docker compose exec namenode hdfs dfs -put -f /workspace/data/access_logs.tsv /dataflix/input/
docker compose exec namenode bash /workspace/scripts/run_streaming.sh \
  /dataflix/input/access_logs.tsv \
  /dataflix/output/log-metrics-v1
```

Il wrapper rifiuta un output già esistente; non cancella nulla automaticamente. La configurazione richiede due reducer, quindi l'output contiene `part-r-00000`, `part-r-00001` e `_SUCCESS`. L'ordine tra i due part file non è globale.

## Riconciliazioni obbligatorie

Nell'output aggregato:

- la somma di tutte le key `STATUS|...` deve essere 50.000;
- la somma di tutte le key `IP|...` deve essere 50.000;
- la somma di tutte le key `DEVICE|...` deve essere 50.000;
- le key `BYTES|...` sommano byte, non record;
- le key `ERROR_PATH|...` sommano soltanto status che iniziano per `5`;
- `DATAFLIX / MalformedLines` deve valere 3.

La validazione automatica ignora l'ordine globale:

```bash
docker compose exec namenode hdfs dfs -cat '/dataflix/output/log-metrics-v1/part-*' \
  > evidence/distributed_metrics.tsv
python3 scripts/validate_metrics.py data/expected_metrics.tsv evidence/distributed_metrics.tsv
```

## Dimostrazione del protocollo Streaming

`stdout` è il canale dati. Il primo TAB separa key e value. `stderr` ospita diagnostica, status e counter. `mapper_broken.py` stampa una riga di debug su `stdout`; il framework la interpreta come record intermedio e può produrre errori o key inattese.

Correzione:

```python
print("DEBUG sto elaborando una riga", file=sys.stderr)
```

## Domande per la correzione collettiva

1. Perché lo stesso IP deve finire sempre nello stesso reducer?
2. Perché due reducer producono due part file?
3. Perché un job `SUCCEEDED` può essere logicamente errato?
4. Quale costo elimina un job map-only?
5. Quale evidenza mostra la qualità dell'input?
6. Che cosa accade se una sola key contiene il 90% dei record?

## Rubrica sintetica — 20 punti

| Area | Punti | Evidenza |
|---|---:|---|
| Preflight | 3 | DataNode e due NodeManager attivi |
| Contratto locale | 4 | pipeline e validazione riuscite |
| Job distribuito | 5 | FINISHED/SUCCEEDED, due reducer |
| Riconciliazione | 4 | counter e output coerenti |
| Insight | 3 | tre risultati motivati |
| Spiegazione tecnica | 1 | shuffle e collo di bottiglia |

## Troubleshooting

### `Connection refused` verso NameNode o ResourceManager

Attendere l'avvio, verificare `docker compose ps` e i log. Controllare che i servizi condividano la rete `dataflix`.

### Nessun NodeManager in YARN

Controllare `yarn.resourcemanager.hostname`, lo shuffle service e i log dei due NodeManager. Verificare che le porte 8042/8043 siano solo esposizioni host diverse dello stesso endpoint container.

### `python3: command not found` nel task

Il test preflight deve intercettarlo. Usare un'immagine che includa Python 3 oppure predisporre un'immagine didattica derivata; non correggere a metà lezione con installazioni non riproducibili.

### Output directory already exists

Comportamento intenzionale. Scegliere un path versionato oppure archiviare/rimuovere quello precedente solo dopo averlo verificato.

### Local test corretto, job distribuito fallito

Verificare `-files`, nome dei file nel comando `-mapper`/`-reducer`, disponibilità di Python sui NodeManager e container log tramite ResourceManager/ApplicationId.

### Key `DEBUG sto elaborando...` nell'output

Diagnostica scritta su `stdout`. Spostarla su `stderr`.

### Valori corretti ma file in ordine diverso

Normale con più reducer. Confrontare per key, non con un semplice confronto testuale dei file concatenati.

### `MalformedLines` diverso da 3

Controllare che il file HDFS corrisponda al dataset rigenerato e che il mapper incrementi il counter per campo mancante e dimensione non numerica.

## Pulizia

`docker compose down` ferma i container e conserva i volumi. `docker compose down -v` elimina l'ambiente HDFS del laboratorio; usarlo soltanto dopo avere esportato le evidenze necessarie.

## Fonti ufficiali

- Apache Hadoop MapReduce Tutorial: https://hadoop.apache.org/docs/current/hadoop-mapreduce-client/hadoop-mapreduce-client-core/MapReduceTutorial.html
- Apache Hadoop Streaming: https://hadoop.apache.org/docs/current/hadoop-streaming/HadoopStreaming.html
- Apache Hadoop YARN Architecture: https://hadoop.apache.org/docs/current/hadoop-yarn/hadoop-yarn-site/YARN.html
- Apache Hadoop YARN Commands: https://hadoop.apache.org/docs/current/hadoop-yarn/hadoop-yarn-site/YarnCommands.html
- Apache Hadoop official container image: https://hub.docker.com/r/apache/hadoop
