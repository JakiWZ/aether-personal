#!/usr/bin/env python3
"""Versione volutamente errata: la diagnostica finisce su stdout e diventa dato."""

import sys

for raw_line in sys.stdin:
    print("DEBUG sto elaborando una riga")
    fields = raw_line.rstrip("\n").split("\t")
    if len(fields) == 8:
        print(f"STATUS|{fields[4]}\t1")
