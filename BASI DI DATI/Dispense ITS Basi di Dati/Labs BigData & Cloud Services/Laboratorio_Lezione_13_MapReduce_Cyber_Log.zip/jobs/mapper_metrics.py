#!/usr/bin/env python3
"""Mapper Streaming: una riga di log può emettere più famiglie di metriche."""

import sys


def emit(key: str, value: int) -> None:
    print(f"{key}\t{value}")


def counter(name: str, amount: int = 1) -> None:
    print(f"reporter:counter:DATAFLIX,{name},{amount}", file=sys.stderr)


for raw_line in sys.stdin:
    fields = raw_line.rstrip("\n").split("\t")
    if len(fields) != 8:
        counter("MalformedLines")
        continue

    timestamp, ip, method, path, status, raw_size, country, device = fields

    try:
        size = int(raw_size)
    except ValueError:
        counter("MalformedLines")
        continue

    if not timestamp or not ip or not status or size < 0:
        counter("MalformedLines")
        continue

    emit(f"STATUS|{status}", 1)
    emit(f"IP|{ip}", 1)
    emit(f"BYTES|{country}", size)
    emit(f"DEVICE|{device}", 1)

    if status.startswith("5"):
        emit(f"ERROR_PATH|{path}", 1)
