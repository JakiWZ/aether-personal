#!/usr/bin/env python3
"""Reducer Streaming: somma valori interi di un flusso già ordinato per key."""

import sys


def counter(name: str, amount: int = 1) -> None:
    print(f"reporter:counter:DATAFLIX,{name},{amount}", file=sys.stderr)


current_key = None
total = 0

for raw_line in sys.stdin:
    try:
        key, raw_value = raw_line.rstrip("\n").split("\t", 1)
        value = int(raw_value)
    except (ValueError, TypeError):
        counter("MalformedIntermediateValues")
        continue

    if current_key is not None and key != current_key:
        print(f"{current_key}\t{total}")
        total = 0

    current_key = key
    total += value

if current_key is not None:
    print(f"{current_key}\t{total}")
