#!/usr/bin/env python3
"""Confronta due file key<TAB>intero ignorando l'ordine globale."""

from pathlib import Path
import sys


def load(path: Path) -> dict[str, int]:
    result: dict[str, int] = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw_line.strip():
            continue
        try:
            key, raw_value = raw_line.split("\t", 1)
            value = int(raw_value)
        except ValueError as exc:
            raise SystemExit(f"{path}:{line_number}: riga non valida: {raw_line!r}") from exc
        result[key] = result.get(key, 0) + value
    return result


if len(sys.argv) != 3:
    raise SystemExit("Uso: validate_metrics.py ATTESO.tsv OTTENUTO.tsv")

expected_path, actual_path = map(Path, sys.argv[1:])
expected = load(expected_path)
actual = load(actual_path)

missing = sorted(expected.keys() - actual.keys())
unexpected = sorted(actual.keys() - expected.keys())
mismatched = sorted(k for k in expected.keys() & actual.keys() if expected[k] != actual[k])

if missing or unexpected or mismatched:
    print("VALIDAZIONE FALLITA")
    if missing:
        print("Key mancanti:", ", ".join(missing[:10]))
    if unexpected:
        print("Key inattese:", ", ".join(unexpected[:10]))
    for key in mismatched[:10]:
        print(f"Valore diverso {key}: atteso={expected[key]} ottenuto={actual[key]}")
    raise SystemExit(1)

print(f"VALIDAZIONE OK: {len(expected)} key, valori identici indipendentemente dall'ordine")
