#!/usr/bin/env python3
"""Genera 50.000 log DATAFLIX validi e tre righe malformate, sempre uguali."""

from datetime import datetime, timedelta, timezone
from pathlib import Path
import random


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "data" / "access_logs.tsv"
VALID_ROWS = 50_000
SEED = 13_013

rng = random.Random(SEED)
start = datetime(2026, 9, 3, 8, 0, tzinfo=timezone.utc)

ips = [f"203.0.113.{i}" for i in range(1, 81)] + [f"198.51.100.{i}" for i in range(1, 41)]
ip_weights = [18 if ip in {"203.0.113.7", "203.0.113.42"} else 1 for ip in ips]
methods = ["GET", "POST", "PUT", "DELETE"]
method_weights = [76, 18, 4, 2]
paths = ["/", "/login", "/catalog", "/search", "/play", "/profile", "/recommendations", "/api/v1/events"]
path_weights = [5, 8, 15, 14, 28, 6, 16, 8]
statuses = ["200", "206", "304", "400", "401", "404", "429", "500", "502", "503"]
status_weights = [62, 8, 8, 3, 3, 7, 3, 3, 1, 2]
countries = ["IT", "DE", "FR", "ES", "US", "BR", "JP"]
country_weights = [28, 12, 12, 10, 22, 9, 7]
devices = ["mobile", "web", "smart_tv", "tablet", "console"]
device_weights = [36, 28, 23, 8, 5]

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with OUTPUT.open("w", encoding="utf-8", newline="") as handle:
    for _ in range(VALID_ROWS):
        moment = start + timedelta(seconds=rng.randrange(0, 86_400))
        timestamp = moment.isoformat(timespec="seconds").replace("+00:00", "Z")
        ip = rng.choices(ips, weights=ip_weights, k=1)[0]
        method = rng.choices(methods, weights=method_weights, k=1)[0]
        path = rng.choices(paths, weights=path_weights, k=1)[0]
        status = rng.choices(statuses, weights=status_weights, k=1)[0]
        size = rng.randint(180, 9_500_000 if path == "/play" else 32_000)
        country = rng.choices(countries, weights=country_weights, k=1)[0]
        device = rng.choices(devices, weights=device_weights, k=1)[0]
        handle.write("\t".join([timestamp, ip, method, path, status, str(size), country, device]) + "\n")

    handle.write("riga-malformata-senza-tab\n")
    handle.write("2026-09-03T12:00:00Z\t203.0.113.5\tGET\n")
    handle.write("2026-09-03T12:00:01Z\t203.0.113.6\tGET\t/play\t200\tnon-numerico\tIT\tweb\n")

print(f"Creato {OUTPUT}: {VALID_ROWS} righe valide + 3 malformate")
