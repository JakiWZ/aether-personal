#!/usr/bin/env bash
set -euo pipefail

INPUT_PATH="${1:-/dataflix/input/access_logs.tsv}"
OUTPUT_PATH="${2:-/dataflix/output/log-metrics-v1}"

if hdfs dfs -test -e "$OUTPUT_PATH"; then
  echo "ERRORE: il path di output esiste già: $OUTPUT_PATH" >&2
  echo "Scegli un nuovo path oppure archivia/rimuovi consapevolmente quello esistente." >&2
  exit 2
fi

mapred streaming \
  -D mapreduce.job.name=dataflix-log-metrics \
  -D mapreduce.job.reduces=2 \
  -files /workspace/jobs/mapper_metrics.py,/workspace/jobs/reducer_sum.py \
  -input "$INPUT_PATH" \
  -output "$OUTPUT_PATH" \
  -mapper "python3 mapper_metrics.py" \
  -reducer "python3 reducer_sum.py"

echo "Job completato. Output: $OUTPUT_PATH"
