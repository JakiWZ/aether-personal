# Cartella evidenze

I comandi del laboratorio salvano qui gli output locali e distribuiti. Conserva soltanto risultati generati dalla tua esecuzione e non inserire dati personali.
