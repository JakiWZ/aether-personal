# Lezione 13 — Cyber Log MapReduce

## Missione

DATAFLIX ha prodotto 50.000 log HTTP validi e tre righe corrotte. Devi eseguire un job MapReduce su HDFS/YARN che produca più famiglie di metriche in un solo passaggio:

- richieste per status HTTP;
- richieste per IP;
- byte trasferiti per paese;
- richieste per dispositivo;
- errori 5xx per endpoint.

Il risultato non è considerato corretto solo perché il job termina: servono prove su cluster, input, stato YARN, counter e valori finali.

## Prerequisiti e regole

- Docker Desktop oppure Docker Engine con il comando `docker compose`;
- almeno 6 GB di RAM disponibili per Docker;
- Python 3 sul computer host;
- porte libere: `9870`, `9864`, `8088`, `8042`, `8043`, `19888`;
- lavorare dalla directory che contiene questo file;
- non usare dati personali: il dataset incluso usa indirizzi IP riservati alla documentazione.

Non eliminare volumi o directory di output senza aver verificato il target. Per fermare il laboratorio usa `docker compose down`; l'opzione `-v` elimina anche i dati HDFS persistenti.

## 1. Avvio e preflight

Avvia i sei servizi:

```bash
docker compose up -d
docker compose ps
```

Attendi circa 30–60 secondi, quindi verifica HDFS e YARN:

```bash
docker compose exec namenode hdfs dfsadmin -report
docker compose exec resourcemanager yarn node -list
docker compose exec nodemanager1 python3 --version
docker compose exec nodemanager2 python3 --version
```

Evidence gate A:

1. HDFS vede un DataNode live.
2. YARN vede due NodeManager in stato `RUNNING`.
3. Entrambi i NodeManager dispongono di Python 3.

Interfacce utili:

- NameNode: <http://localhost:9870>
- DataNode: <http://localhost:9864>
- ResourceManager: <http://localhost:8088>
- NodeManager 1: <http://localhost:8042>
- NodeManager 2: <http://localhost:8043>
- JobHistory: <http://localhost:19888>

## 2. Dataset deterministico

Rigenera il file per verificare che sia riproducibile:

```bash
python3 scripts/generate_logs.py
wc -l data/access_logs.tsv
head -n 3 data/access_logs.tsv
tail -n 4 data/access_logs.tsv
```

Domande:

1. Quante righe totali contiene il file?
2. Perché il numero è superiore a 50.000?
3. Quali campi sono separati da TAB?

## 3. Test locale del contratto

Prima di coinvolgere il cluster, esegui la stessa pipeline in locale:

```bash
python3 jobs/mapper_metrics.py < data/access_logs.tsv \
  | LC_ALL=C sort \
  | python3 jobs/reducer_sum.py \
  > evidence/local_metrics.tsv
```

Il mapper deve scrivere i counter su `stderr` e le coppie su `stdout`. Controlla:

```bash
head -n 12 evidence/local_metrics.tsv
python3 scripts/validate_metrics.py data/expected_metrics.tsv evidence/local_metrics.tsv
```

Evidence gate B: la validazione termina con `VALIDAZIONE OK`.

## 4. Caricamento in HDFS

```bash
docker compose exec namenode hdfs dfs -mkdir -p /dataflix/input
docker compose exec namenode hdfs dfs -put -f /workspace/data/access_logs.tsv /dataflix/input/
docker compose exec namenode hdfs dfs -ls -h /dataflix/input
docker compose exec namenode hdfs dfs -cat /dataflix/input/access_logs.tsv | head -n 2
```

Evidence gate C: il file è visibile in HDFS e le prime righe hanno otto campi.

## 5. Job distribuito con due reducer

Il path di output deve essere nuovo. Avvia il job:

```bash
docker compose exec namenode bash /workspace/scripts/run_streaming.sh \
  /dataflix/input/access_logs.tsv \
  /dataflix/output/log-metrics-v1
```

Durante l'esecuzione apri la ResourceManager UI. Annota:

- ApplicationId;
- stato finale;
- numero di map task;
- numero di reduce task;
- NodeManager utilizzati;
- counter `DATAFLIX / MalformedLines`.

Da terminale:

```bash
docker compose exec resourcemanager yarn application -list -appStates ALL
docker compose exec namenode hdfs dfs -ls /dataflix/output/log-metrics-v1
docker compose exec namenode hdfs dfs -cat '/dataflix/output/log-metrics-v1/part-*' \
  > evidence/distributed_metrics.tsv
python3 scripts/validate_metrics.py data/expected_metrics.tsv evidence/distributed_metrics.tsv
```

Evidence gate D:

1. l'applicazione termina `FINISHED / SUCCEEDED`;
2. esistono due file `part-r-*` e il marcatore `_SUCCESS`;
3. il counter `MalformedLines` vale 3;
4. il risultato distribuito coincide con quello atteso.

## 6. Challenge — Data Detective

Trova almeno tre insight non già esplicitati nella missione. Puoi filtrare l'output con comandi shell oppure scrivere un breve script. Idee:

- quali sono i cinque IP più attivi?
- quale endpoint genera più errori 5xx?
- qual è il paese con più byte trasferiti?
- quale quota di richieste termina con status 5xx?
- esiste una hot key evidente?

Per ogni insight consegna:

1. domanda;
2. comando o codice;
3. risultato numerico;
4. interpretazione in una frase;
5. limite dell'analisi.

## 7. Esperimento controllato — stdout non è una console

Esegui soltanto in locale il mapper volutamente errato:

```bash
printf '2026-09-03T10:00:00Z\t203.0.113.7\tGET\t/login\t404\t842\tIT\tweb\n' \
  | python3 jobs/mapper_broken.py
```

Spiega perché la riga `DEBUG` verrebbe interpretata come dato intermedio. Correggila senza modificare la metrica prodotta.

## 8. Rilancio e output esistente

Rilancia lo stesso comando sul medesimo path. Il wrapper deve fermarsi prima del job. Spiega perché questo comportamento protegge i risultati precedenti.

Per una seconda esecuzione scegli, per esempio, `/dataflix/output/log-metrics-v2`. Se devi rimuovere un output, verifica prima il path:

```bash
docker compose exec namenode hdfs dfs -ls /dataflix/output
```

## Consegna

Compila `EVIDENZE.md` con:

- nominativi del gruppo;
- output dei quattro evidence gate;
- ApplicationId e screenshot ResourceManager;
- counter `MalformedLines`;
- confronto locale/distribuito;
- tre insight;
- risposta: «Perché lo shuffle richiede rete?»;
- risposta: «Perché un Reducer può diventare il collo di bottiglia?».

## Arresto

```bash
docker compose down
```

Solo se vuoi cancellare anche HDFS e i dati locali dei NodeManager:

```bash
docker compose down -v
```
