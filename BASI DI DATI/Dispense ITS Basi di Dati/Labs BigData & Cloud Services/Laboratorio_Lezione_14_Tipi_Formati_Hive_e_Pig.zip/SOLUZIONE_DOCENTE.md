# Soluzione docente — Lezione 14

## Risultato atteso

Il dataset contiene 50.006 righe fisiche: 50.000 eventi validi e 6 eventi `BAD-*`. La tabella `raw_views` deve esporli tutti; `curated_views` deve contenerne esattamente 50.000.

## Fase 1

La tabella raw usa solo `STRING` perché il primo scopo è preservare l'evidenza originale. Se dichiarassimo subito `INT` e `TIMESTAMP`, conversioni fallite potrebbero apparire come `NULL` senza distinguere facilmente il valore originario.

`raw_views` è esterna: Hive governa i metadata ma punta a file già esistenti. In assenza di `external.table.purge=true`, eliminare la tabella rimuove la definizione, non i file.

## Fase 2

Risultati attesi:

| Controllo | Conteggio |
|---|---:|
| Durata non valida | 2 |
| Timestamp non valido | 2 |
| Paese mancante | 1 |
| Dimensioni fuori dominio | 1 |

Le categorie sono state costruite per non sovrapporsi. Un `CAST` fallito restituisce `NULL`: ciò rende semplice contare gli errori, ma una query non controllata potrebbe confondere “valore assente” con “valore non convertibile”.

## Fase 3

Controlli:

```sql
SELECT COUNT(*) FROM curated_views;
-- 50000

SELECT COUNT(*)
FROM curated_views
WHERE event_id LIKE 'BAD-%';
-- 0

SHOW PARTITIONS curated_views;
DESCRIBE FORMATTED curated_views;
```

La tabella è gestita, scritta in Parquet e partizionata per `event_date` e `country`. Il warehouse è persistito nel volume Docker `hive_warehouse`.

## Query aggiuntive

### Minuti totali per giorno

```sql
SELECT event_date,
       ROUND(SUM(duration_seconds) / 60.0, 2) AS minutes_watched
FROM curated_views
GROUP BY event_date
ORDER BY event_date;
```

### Percentuale 4K per paese

```sql
SELECT country,
       ROUND(100.0 * SUM(CASE WHEN quality = '4K' THEN 1 ELSE 0 END) / COUNT(*), 2) AS pct_4k
FROM curated_views
GROUP BY country
ORDER BY pct_4k DESC;
```

### Top film su TV con soglia

```sql
SELECT movie_id, COUNT(*) AS tv_events
FROM curated_views
WHERE device = 'tv'
GROUP BY movie_id
HAVING COUNT(*) >= 20
ORDER BY tv_events DESC, movie_id
LIMIT 5;
```

## EXPLAIN

Non chiedere agli studenti di decifrare ogni riga. Devono trovare la prova che il predicato sulle colonne di partizione restringe l'insieme delle partizioni prima della scansione. Se la resa del piano cambia tra versioni, accettare termini equivalenti come `partition`, `pruning`, `filter` o l'elenco delle specifiche selezionate.

## Hive e Pig

Risposta modello: HiveQL esprime in modo compatto il risultato desiderato e lascia il piano all'engine. Pig Latin espone una sequenza di relazioni nominate; è più procedurale e rende visibili gli stadi intermedi. Entrambi evitano di scrivere direttamente Mapper e Reducer. Il confronto prepara Spark DataFrame: API dichiarative costruiscono un piano che un motore distribuito ottimizza ed esegue.

## Debrief

Domande finali:

1. Quale decisione appartiene allo schema e quale al formato?
2. Perché Parquet non ripara dati semanticamente sbagliati?
3. Quando una partizione diventa troppo piccola?
4. Che cosa controlla il Metastore e che cosa resta nello storage?
5. Quale parte di Pig ritroveremo nelle trasformazioni Spark?

