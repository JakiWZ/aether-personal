# Laboratorio Lezione 14 — Tipi di dato, formati, Hive e Pig

Questo pacchetto accompagna la Lezione 14 del corso DATAFLIX.

Obiettivo: trasformare eventi grezzi in una tabella Hive tipizzata, partizionata e memorizzata in Parquet, quindi confrontare la stessa pipeline con Pig Latin.

## Avvio rapido

1. Installare Docker Desktop oppure Docker Engine con Compose v2.
2. Eseguire `python scripts/generate_views.py`.
3. Eseguire `docker compose up -d`.
4. Attendere HiveServer2 con `bash scripts/wait_for_hive.sh`.
5. Eseguire gli script SQL nell'ordine indicato in `LAB_STUDENTE.md`.

L'immagine `apache/hive:4.2.1` e la modalità standalone con metastore Derby seguono il quickstart ufficiale Apache Hive. L'ambiente è didattico: il warehouse è locale al container, mentre in produzione Hive legge normalmente da storage distribuito o a oggetti.

## Contenuto

- `LAB_STUDENTE.md`: consegna, tempi, controlli ed evidenze.
- `SOLUZIONE_DOCENTE.md`: percorso commentato e risultati attesi.
- `EVIDENZE.md`: scheda di raccolta delle prove.
- `docker-compose.yml`: HiveServer2 standalone.
- `scripts/`: generazione dataset, attesa e runner.
- `sql/`: cinque tappe HiveQL.
- `pig/`: traduzione della pipeline in Pig Latin.
- `data/`: dataset sintetico deterministico e risultati attesi.

## Requisiti indicativi

- 4 GB RAM liberi per Docker.
- Porte locali 10000 e 10002 disponibili.
- Python 3.10+ soltanto per rigenerare il dataset.

## Arresto

`docker compose down`

Per rimuovere anche il volume del warehouse, dopo aver verificato di non dover conservare i risultati:

`docker compose down -v`

