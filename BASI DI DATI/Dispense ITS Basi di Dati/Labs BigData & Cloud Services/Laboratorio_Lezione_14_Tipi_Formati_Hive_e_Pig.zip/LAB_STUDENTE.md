# DATAFLIX — Dal TSV grezzo al Parquet interrogabile

Durata indicativa: 2 ore e 30 minuti. Lavoro in coppia consigliato.

## Scenario

DATAFLIX riceve eventi di visualizzazione come testo delimitato da TAB. I producer non sono perfetti: alcune righe contengono durate, timestamp o dimensioni non valide. Il team analytics vuole una tabella affidabile, tipizzata e veloce da interrogare.

Non correggere il file a mano. La qualità deve essere misurata e resa ripetibile nella pipeline.

## Obiettivi

Al termine saprai:

- distinguere schema fisico e schema logico;
- creare una tabella Hive esterna di staging;
- usare `CAST`, `NULL` e controlli di dominio;
- costruire una tabella gestita in Parquet;
- partizionare per data e paese;
- usare `GROUP BY`, `HAVING`, `ORDER BY` ed `EXPLAIN`;
- tradurre una query Hive in una pipeline Pig Latin.

## Fase 0 — Preflight, 10 minuti

1. Rigenera i dati: `python scripts/generate_views.py`.
2. Avvia l'ambiente: `docker compose up -d`.
3. Attendi: `bash scripts/wait_for_hive.sh`.
4. Apri la UI: `http://localhost:10002/`.
5. Controlla lo stato: `docker compose ps`.

Evidenza richiesta: `SELECT 1` riuscita e container healthy.

## Fase 1 — Schema-on-read, 15 minuti

Esegui:

```bash
docker compose exec -T hiveserver2 \
  beeline -u 'jdbc:hive2://localhost:10000/default' \
  --showHeader=true --outputformat=table \
  -f /workspace/sql/01_setup_raw.sql
```

Rispondi:

1. Perché tutte le colonne di staging sono `STRING`?
2. Dove sono i file e dove sono i metadata?
3. Che cosa accadrebbe ai file con `DROP TABLE raw_views`?

## Fase 2 — Quality gate, 20 minuti

Esegui `02_quality_gate.sql` con lo stesso comando. Non guardare subito la soluzione.

Produci una tabella con:

- durata non convertibile;
- timestamp non convertibile;
- paese mancante;
- dimensione fuori dominio.

Domanda chiave: perché un `CAST` fallito che restituisce `NULL` è utile ma anche pericoloso?

## Fase 3 — Tabella curata, 25 minuti

Esegui `03_curated_parquet.sql`.

Verifica:

- numero di righe;
- tipi reali delle colonne;
- formato di input/output;
- partizioni create;
- assenza degli identificatori `BAD-*`.

Scrivi una query che dimostri l'ultima verifica.

## Fase 4 — Analytics, 30 minuti

Esegui `04_analytics.sql`, poi aggiungi tre query tue:

1. minuti totali per giorno;
2. percentuale di eventi 4K per paese;
3. top 5 film su `tv` con almeno 20 eventi.

Per ogni query annota: filtri di riga, chiave di raggruppamento e metrica.

## Fase 5 — Il piano racconta il costo, 20 minuti

Esegui `05_explain.sql`.

Confronta la query con filtro su `event_date` e `country` con quella senza filtro. Cerca nel piano riferimenti alle partizioni selezionate o eliminate.

Non limitarti a scrivere “è più veloce”: spiega quali directory/partizioni possono essere escluse prima della lettura.

## Fase 6 — Hive vs Pig, 15 minuti

Apri `pig/dataflix_metrics.pig` e `pig/HIVE_VS_PIG.md`.

1. Individua `LOAD`, `FILTER`, `FOREACH`, `GROUP`, `ORDER` e `DUMP`.
2. Disegna la pipeline come trasformazioni successive.
3. Confrontala con la query SQL equivalente.
4. Scrivi cinque righe: quale forma useresti per una domanda analitica e quale per una trasformazione procedurale?

L'esecuzione di Pig è opzionale: il pacchetto privilegia un'immagine ufficiale Hive e non introduce immagini Pig non ufficiali. Il docente può usare una propria installazione Apache Pig 0.18.0 in local mode.

## Challenge finale — Tre insight non richiesti, 15 minuti

Trova tre osservazioni utili a DATAFLIX. Ogni insight deve includere:

- query;
- risultato;
- interpretazione;
- un limite o rischio di lettura.

## Consegna

Consegna `EVIDENZE.md` compilato, le tre query aggiuntive e un breve confronto Hive/Pig.
