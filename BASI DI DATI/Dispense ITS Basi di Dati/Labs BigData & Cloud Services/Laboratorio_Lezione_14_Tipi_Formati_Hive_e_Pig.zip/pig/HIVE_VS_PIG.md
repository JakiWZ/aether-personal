# Stessa domanda, due forme mentali

## HiveQL: dichiarare il risultato

```sql
SELECT movie_id, COUNT(*) AS events
FROM curated_views
GROUP BY movie_id
ORDER BY events DESC
LIMIT 10;
```

Il motore decide il piano fisico. Il lettore vede soprattutto **che cosa** vuole ottenere.

## Pig Latin: descrivere il flusso

```pig
by_movie = GROUP typed BY movie_id;
movie_counts = FOREACH by_movie
  GENERATE group AS movie_id, COUNT(typed) AS events;
top_movies = ORDER movie_counts BY events DESC;
DUMP (LIMIT top_movies 10);
```

Il lettore vede una sequenza di relazioni. La struttura rende esplicito **come il dato passa** da una trasformazione alla successiva.

## Domande per la discussione

1. Quale versione comunica meglio la domanda di business?
2. Quale rende più visibili gli stadi intermedi?
3. Dove preferiresti inserire una trasformazione custom complessa?
4. Perché conoscere Pig aiuta a capire DataFrame e pipeline moderne?

