-- Traduzione didattica della pipeline Hive in Pig Latin.
-- Esecuzione prevista: pig -x local dataflix_metrics.pig

raw = LOAD '/workspace/data/raw_views/views.tsv' USING PigStorage('\t') AS (
  event_id:chararray,
  user_id:chararray,
  movie_id:chararray,
  event_ts_raw:chararray,
  duration_raw:chararray,
  country_raw:chararray,
  device_raw:chararray,
  quality_raw:chararray,
  event_type_raw:chararray
);

valid = FILTER raw BY
  duration_raw MATCHES '[0-9]+'
  AND event_ts_raw MATCHES '[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}'
  AND country_raw IS NOT NULL AND country_raw != ''
  AND (device_raw == 'mobile' OR device_raw == 'tv' OR device_raw == 'web' OR device_raw == 'tablet')
  AND (quality_raw == 'SD' OR quality_raw == 'HD' OR quality_raw == 'FHD' OR quality_raw == '4K')
  AND (event_type_raw == 'play' OR event_type_raw == 'pause' OR event_type_raw == 'resume' OR event_type_raw == 'complete');

typed = FOREACH valid GENERATE
  event_id,
  user_id,
  movie_id,
  event_ts_raw AS event_ts,
  (int)duration_raw AS duration_seconds,
  country_raw AS country,
  device_raw AS device,
  quality_raw AS quality,
  event_type_raw AS event_type;

by_movie = GROUP typed BY movie_id;
movie_counts = FOREACH by_movie GENERATE group AS movie_id, COUNT(typed) AS events;
top_movies = ORDER movie_counts BY events DESC;

DUMP (LIMIT top_movies 10);

