#!/usr/bin/env bash
set -euo pipefail

for sql_file in \
  /workspace/sql/01_setup_raw.sql \
  /workspace/sql/02_quality_gate.sql \
  /workspace/sql/03_curated_parquet.sql \
  /workspace/sql/04_analytics.sql \
  /workspace/sql/05_explain.sql; do
  echo "Esecuzione ${sql_file}"
  docker compose exec -T hiveserver2 \
    beeline -u 'jdbc:hive2://localhost:10000/default' \
    --showHeader=true --outputformat=table -f "${sql_file}"
done

