#!/usr/bin/env bash
set -euo pipefail

for attempt in $(seq 1 40); do
  if docker compose exec -T hiveserver2 \
    beeline -u 'jdbc:hive2://localhost:10000/default' -e 'SELECT 1' >/dev/null 2>&1; then
    echo "HiveServer2 pronto."
    exit 0
  fi
  echo "Attesa HiveServer2: tentativo ${attempt}/40"
  sleep 5
done

echo "HiveServer2 non è diventato disponibile. Controllare: docker compose logs hiveserver2" >&2
exit 1

