#!/usr/bin/env python3
"""Genera 50.000 eventi DATAFLIX validi e 6 record deliberatamente sporchi."""

from __future__ import annotations

import json
import random
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

SEED = 140314
VALID_ROWS = 50_000
ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "data" / "raw_views"
OUT_FILE = OUT_DIR / "views.tsv"
EXPECTED = ROOT / "data" / "expected_results.json"

COUNTRIES = ["IT", "IT", "IT", "FR", "DE", "ES", "US", "GB"]
DEVICES = ["mobile", "mobile", "tv", "tv", "web", "tablet"]
QUALITIES = ["SD", "HD", "HD", "FHD", "FHD", "4K"]
EVENT_TYPES = ["play", "play", "pause", "resume", "complete"]
MOVIES = [f"MOV-{i:04d}" for i in range(1, 401)]
USERS = [f"USR-{i:06d}" for i in range(1, 8001)]


def weighted_duration(rng: random.Random, event_type: str) -> int:
    if event_type == "complete":
        return rng.randint(1800, 7800)
    if event_type == "pause":
        return rng.randint(20, 1800)
    return rng.randint(60, 4200)


def main() -> None:
    rng = random.Random(SEED)
    start = datetime(2026, 9, 1, 0, 0, 0)
    counters = {
        "country": Counter(),
        "device": Counter(),
        "quality": Counter(),
        "event_type": Counter(),
        "movie": Counter(),
        "event_date": Counter(),
    }
    total_duration = 0
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    with OUT_FILE.open("w", encoding="utf-8", newline="") as handle:
        for index in range(1, VALID_ROWS + 1):
            # I primi 1.200 eventi favoriscono tre film per rendere leggibile la top 3.
            if index <= 600:
                movie = "MOV-0042"
            elif index <= 950:
                movie = "MOV-0007"
            elif index <= 1200:
                movie = "MOV-0314"
            else:
                movie = rng.choice(MOVIES)

            event_type = rng.choice(EVENT_TYPES)
            timestamp = start + timedelta(seconds=rng.randrange(3 * 24 * 3600))
            duration = weighted_duration(rng, event_type)
            country = rng.choice(COUNTRIES)
            device = rng.choice(DEVICES)
            quality = rng.choice(QUALITIES)
            row = [
                f"EVT-{index:07d}",
                rng.choice(USERS),
                movie,
                timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                str(duration),
                country,
                device,
                quality,
                event_type,
            ]
            handle.write("\t".join(row) + "\n")
            counters["country"][country] += 1
            counters["device"][device] += 1
            counters["quality"][quality] += 1
            counters["event_type"][event_type] += 1
            counters["movie"][movie] += 1
            counters["event_date"][timestamp.strftime("%Y-%m-%d")] += 1
            total_duration += duration

        poisoned = [
            ["BAD-0001", "USR-000001", "MOV-0042", "2026-09-02 12:00:00", "not-a-number", "IT", "web", "HD", "play"],
            ["BAD-0002", "USR-000002", "MOV-0007", "2026-09-02 12:05:00", "", "FR", "mobile", "FHD", "pause"],
            ["BAD-0003", "USR-000003", "MOV-0314", "03/09/2026 08:30", "180", "DE", "tv", "4K", "play"],
            ["BAD-0004", "USR-000004", "MOV-0010", "impossibile", "240", "ES", "tablet", "SD", "play"],
            ["BAD-0005", "USR-000005", "MOV-0011", "2026-09-03 09:00:00", "300", "", "web", "HD", "resume"],
            ["BAD-0006", "USR-000006", "MOV-0012", "2026-09-03 09:10:00", "360", "US", "console", "HDR", "rewind"],
        ]
        for row in poisoned:
            handle.write("\t".join(row) + "\n")

    expected = {
        "seed": SEED,
        "physical_rows": VALID_ROWS + len(poisoned),
        "valid_rows": VALID_ROWS,
        "invalid_rows": len(poisoned),
        "total_duration_seconds": total_duration,
        "average_duration_seconds": round(total_duration / VALID_ROWS, 4),
        "counts": {name: dict(counter) for name, counter in counters.items()},
        "top_movies": counters["movie"].most_common(10),
        "quality_checks": {
            "invalid_duration": 2,
            "invalid_timestamp": 2,
            "missing_country": 1,
            "invalid_dimensions": 1,
        },
    }
    EXPECTED.write_text(json.dumps(expected, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Creato {OUT_FILE} con {VALID_ROWS + len(poisoned)} righe fisiche")
    print(f"Creato {EXPECTED}")


if __name__ == "__main__":
    main()

