# Evidence Gate — Lezione 14

Compilare una riga per ogni prova. Allegare screenshot o output testuale.

| # | Evidenza | Comando / query | Osservazione | Interpretazione |
|---:|---|---|---|---|
| 1 | HiveServer2 raggiungibile | `SELECT 1` |  |  |
| 2 | Tabella raw esterna | `DESCRIBE FORMATTED raw_views` |  |  |
| 3 | 50.006 righe fisiche | `COUNT(*)` su `raw_views` |  |  |
| 4 | 6 record esclusi | query quality gate |  |  |
| 5 | 50.000 righe curate | `COUNT(*)` su `curated_views` |  |  |
| 6 | Storage Parquet | `DESCRIBE FORMATTED curated_views` |  |  |
| 7 | Partizioni create | `SHOW PARTITIONS curated_views` |  |  |
| 8 | Partition pruning | confronto fra i due `EXPLAIN` |  |  |
| 9 | Top 3 film coerente | query + `expected_results.json` |  |  |
| 10 | Hive vs Pig | confronto scritto in 5 righe |  |  |

## Check finale

- Il totale raw è 50.006.
- Il totale curated è 50.000.
- Nessun record `BAD-*` compare nella tabella curated.
- La query del 2 settembre legge soltanto le partizioni richieste.
- Lo studente sa spiegare la differenza tra tipo, schema, formato e SerDe.

