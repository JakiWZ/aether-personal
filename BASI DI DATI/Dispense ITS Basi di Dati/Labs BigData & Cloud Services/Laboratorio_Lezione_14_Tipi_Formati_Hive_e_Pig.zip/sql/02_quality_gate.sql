USE dataflix;

SELECT
  COUNT(*) AS physical_rows,
  SUM(CASE WHEN CAST(duration_raw AS INT) IS NULL THEN 1 ELSE 0 END) AS invalid_duration,
  SUM(CASE WHEN CAST(event_ts_raw AS TIMESTAMP) IS NULL THEN 1 ELSE 0 END) AS invalid_timestamp,
  SUM(CASE WHEN country_raw IS NULL OR TRIM(country_raw) = '' THEN 1 ELSE 0 END) AS missing_country,
  SUM(CASE
        WHEN device_raw NOT IN ('mobile','tv','web','tablet')
          OR quality_raw NOT IN ('SD','HD','FHD','4K')
          OR event_type_raw NOT IN ('play','pause','resume','complete')
        THEN 1 ELSE 0 END) AS invalid_dimensions
FROM raw_views;

SELECT *
FROM raw_views
WHERE CAST(duration_raw AS INT) IS NULL
   OR CAST(event_ts_raw AS TIMESTAMP) IS NULL
   OR country_raw IS NULL OR TRIM(country_raw) = ''
   OR device_raw NOT IN ('mobile','tv','web','tablet')
   OR quality_raw NOT IN ('SD','HD','FHD','4K')
   OR event_type_raw NOT IN ('play','pause','resume','complete')
ORDER BY event_id;

