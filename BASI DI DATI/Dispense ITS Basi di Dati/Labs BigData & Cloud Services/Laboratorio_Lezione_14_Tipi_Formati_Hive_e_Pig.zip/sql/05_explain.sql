USE dataflix;

EXPLAIN
SELECT country, COUNT(*) AS events
FROM curated_views
WHERE event_date = DATE '2026-09-02'
  AND country = 'IT'
GROUP BY country;

EXPLAIN
SELECT country, COUNT(*) AS events
FROM curated_views
GROUP BY country;

