USE dataflix;

SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;

DROP TABLE IF EXISTS curated_views;

CREATE TABLE curated_views (
  event_id STRING,
  user_id STRING,
  movie_id STRING,
  event_ts TIMESTAMP,
  duration_seconds INT,
  device STRING,
  quality STRING,
  event_type STRING
)
PARTITIONED BY (
  event_date DATE,
  country STRING
)
STORED AS PARQUET;

INSERT OVERWRITE TABLE curated_views PARTITION (event_date, country)
SELECT
  event_id,
  user_id,
  movie_id,
  CAST(event_ts_raw AS TIMESTAMP) AS event_ts,
  CAST(duration_raw AS INT) AS duration_seconds,
  device_raw AS device,
  quality_raw AS quality,
  event_type_raw AS event_type,
  CAST(event_ts_raw AS DATE) AS event_date,
  country_raw AS country
FROM raw_views
WHERE CAST(duration_raw AS INT) IS NOT NULL
  AND CAST(event_ts_raw AS TIMESTAMP) IS NOT NULL
  AND country_raw IS NOT NULL AND TRIM(country_raw) <> ''
  AND device_raw IN ('mobile','tv','web','tablet')
  AND quality_raw IN ('SD','HD','FHD','4K')
  AND event_type_raw IN ('play','pause','resume','complete');

SELECT COUNT(*) AS curated_rows FROM curated_views;
SHOW PARTITIONS curated_views;
DESCRIBE FORMATTED curated_views;

