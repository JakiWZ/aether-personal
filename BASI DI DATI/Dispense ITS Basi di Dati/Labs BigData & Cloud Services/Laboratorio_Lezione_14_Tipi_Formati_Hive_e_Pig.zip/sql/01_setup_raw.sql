DROP DATABASE IF EXISTS dataflix CASCADE;
CREATE DATABASE dataflix;
USE dataflix;

CREATE EXTERNAL TABLE raw_views (
  event_id STRING,
  user_id STRING,
  movie_id STRING,
  event_ts_raw STRING,
  duration_raw STRING,
  country_raw STRING,
  device_raw STRING,
  quality_raw STRING,
  event_type_raw STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION 'file:///workspace/data/raw_views';

SELECT COUNT(*) AS physical_rows FROM raw_views;
SELECT * FROM raw_views LIMIT 8;
DESCRIBE FORMATTED raw_views;

