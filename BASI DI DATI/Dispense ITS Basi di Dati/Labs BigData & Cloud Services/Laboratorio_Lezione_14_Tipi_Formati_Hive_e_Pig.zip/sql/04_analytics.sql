USE dataflix;

-- 1. Film più osservati.
SELECT movie_id, COUNT(*) AS events
FROM curated_views
GROUP BY movie_id
ORDER BY events DESC, movie_id
LIMIT 10;

-- 2. Paesi con più minuti visti.
SELECT country,
       ROUND(SUM(duration_seconds) / 60.0, 2) AS minutes_watched
FROM curated_views
GROUP BY country
ORDER BY minutes_watched DESC;

-- 3. Distribuzione per dispositivo e qualità.
SELECT device, quality, COUNT(*) AS events
FROM curated_views
GROUP BY device, quality
ORDER BY device, events DESC;

-- 4. Utenti con durata media significativa: WHERE filtra righe, HAVING filtra gruppi.
SELECT user_id,
       COUNT(*) AS events,
       ROUND(AVG(duration_seconds), 2) AS avg_duration_seconds
FROM curated_views
WHERE event_type IN ('play','complete')
GROUP BY user_id
HAVING COUNT(*) >= 5
ORDER BY avg_duration_seconds DESC
LIMIT 15;

-- 5. Query con partition pruning.
SELECT country, COUNT(*) AS events
FROM curated_views
WHERE event_date = DATE '2026-09-02'
  AND country IN ('IT','FR')
GROUP BY country
ORDER BY country;

