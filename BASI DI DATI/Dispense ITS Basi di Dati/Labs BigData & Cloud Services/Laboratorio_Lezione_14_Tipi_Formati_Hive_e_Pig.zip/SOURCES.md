# Fonti ufficiali

- Apache Hive — Quickstart con Docker e immagine 4.2.1: https://hive.apache.org/development/quickstart/
- Apache Hive — LanguageManual Types: https://hive.apache.org/docs/latest/language/languagemanual-types/
- Apache Hive — LanguageManual DDL: https://hive.apache.org/docs/latest/language/languagemanual-ddl/
- Apache Hive — LanguageManual Select, Group By ed Explain: https://hive.apache.org/docs/latest/language/
- Apache Parquet — Overview: https://parquet.apache.org/docs/overview/
- Apache ORC — Background: https://orc.apache.org/docs/
- Apache Avro — Specification: https://avro.apache.org/docs/current/specification/
- Apache Pig — progetto e release 0.18.0: https://pig.apache.org/

Versioni e output di `EXPLAIN` possono cambiare. Verificare il pacchetto prima di una futura erogazione del corso.

