# Lezione 12 — HDFS e “Kill the Node”

## Obiettivo

Osservare un file HDFS come insieme di blocchi replicati, fermare un DataNode, distinguere rilevazione del guasto e recupero, quindi verificare che il file resti leggibile.

## Sicurezza e prerequisiti

- Docker Desktop o Docker Engine con `docker compose` v2.
- Almeno 4 GB di RAM disponibili per il laboratorio.
- Porte host `9870`, `9864`, `9865` e `9866` libere.
- Il cluster non è autenticato: usarlo soltanto in locale e con dati sintetici.
- I timeout HDFS sono ridotti intenzionalmente per rendere visibile il guasto in aula. Non riutilizzare questa configurazione in produzione.

## 1. Avvio e prova del cluster

Eseguire dalla directory che contiene `docker-compose.yml`:

```bash
docker compose pull
docker compose up -d
docker compose ps
```

Attendere che i tre DataNode si registrino, quindi verificare:

```bash
docker compose exec namenode hdfs dfsadmin -report -live
```

Aprire anche `http://localhost:9870` e annotare il numero di DataNode live.

## 2. Creazione di un file multi-blocco

```bash
docker compose exec namenode bash -lc '
  dd if=/dev/urandom of=/tmp/dataflix.bin bs=1M count=8 status=none
  sha256sum /tmp/dataflix.bin
  hdfs dfs -mkdir -p /dataflix/raw
  hdfs dfs -put -f /tmp/dataflix.bin /dataflix/raw/
  hdfs dfs -setrep -w 2 /dataflix/raw/dataflix.bin
'
```

Osservare blocchi, repliche e posizioni:

```bash
docker compose exec namenode \
  hdfs fsck /dataflix/raw/dataflix.bin -files -blocks -locations
```

## 3. Congelare il recovery

```bash
docker compose exec namenode hdfs dfsadmin -safemode enter
docker compose exec namenode hdfs dfsadmin -safemode get
```

SafeMode serve qui a separare didatticamente il momento in cui il nodo viene dichiarato morto dal momento in cui HDFS ricrea le copie.

## 4. Kill the Node

Sul computer host:

```bash
docker compose stop datanode2
```

Controllare periodicamente finché DataNode 2 appare tra i nodi morti:

```bash
docker compose exec namenode hdfs dfsadmin -report -dead
```

Il timeout del laboratorio è breve, ma non istantaneo. Usare anche la UI del NameNode e i log:

```bash
docker compose logs --tail=80 namenode datanode2
```

## 5. Osservare il problema prima del recupero

```bash
docker compose exec namenode \
  hdfs fsck /dataflix/raw/dataflix.bin -files -blocks -locations
```

Annotare quanti blocchi sono sotto-replicati. Verificare che il file sia ancora leggibile:

```bash
docker compose exec namenode bash -lc \
  'hdfs dfs -cat /dataflix/raw/dataflix.bin | sha256sum'
```

Provare anche una scrittura mentre il cluster è in SafeMode:

```bash
printf 'test\n' | docker compose exec -T namenode \
  hdfs dfs -put - /dataflix/raw/should-fail.txt
```

La scrittura deve essere rifiutata; non è un errore del laboratorio.

## 6. Lasciare agire HDFS

```bash
docker compose exec namenode hdfs dfsadmin -safemode leave
```

Ripetere il controllo ogni pochi secondi:

```bash
docker compose exec namenode \
  hdfs fsck /dataflix/raw/dataflix.bin -files -blocks -locations
```

La prova è completata quando i blocchi interessati hanno nuovamente replication factor 2 sui due DataNode rimasti.

## 7. Ripristino del terzo DataNode

```bash
docker compose start datanode2
docker compose exec namenode hdfs dfsadmin -report -live
```

Attendere finché i DataNode live tornano a tre. HDFS potrà eliminare eventuali copie in eccesso secondo le proprie policy.

## 8. Consegna

Per ciascun checkpoint registrare comando o UI, evidenza osservata e spiegazione:

1. Tre DataNode live prima del guasto.
2. File da 8 MB diviso in più blocchi con replication factor 2.
3. DataNode 2 rilevato come dead.
4. Blocchi sotto-replicati mentre SafeMode blocca il recovery.
5. Re-replication dopo l’uscita da SafeMode.
6. File ancora leggibile e cluster riportato a tre DataNode live.

## 9. Pulizia

Il comando seguente rimuove esclusivamente container, rete e volumi nominati da questo progetto didattico. Verificare di essere nella directory corretta:

```bash
docker compose down -v
```

## Domande finali

1. Perché il NameNode non è diventato un collo di bottiglia sul payload?
2. Che differenza hai osservato tra heartbeat e BlockReport?
3. Perché il file era leggibile anche con un DataNode morto?
4. Perché abbiamo scelto tre DataNode e replication factor 2?
5. In che modo la replica è diversa da un backup?
